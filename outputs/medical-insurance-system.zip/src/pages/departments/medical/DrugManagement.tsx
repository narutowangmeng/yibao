import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Pill, Search, Plus, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';

const tabs = [
  { id: 'directory', label: '药品目录', icon: Pill },
  { id: 'procurement', label: '药品采购', icon: Plus },
  { id: 'price', label: '价格监测', icon: TrendingUp },
  { id: 'supply', label: '供应保障', icon: CheckCircle },
  { id: 'regulation', label: '使用监管', icon: AlertCircle }
];

const mockDrugs = [
  { id: 1, code: 'YP001', name: '阿莫西林胶囊', category: '抗生素', price: 12.5, stock: 5000, status: '正常' },
  { id: 2, code: 'YP002', name: '布洛芬缓释片', category: '解热镇痛', price: 28.0, stock: 3200, status: '正常' },
  { id: 3, code: 'YP003', name: '连花清瘟胶囊', category: '中成药', price: 35.0, stock: 800, status: '库存不足' }
];

export default function DrugManagement() {
  const [activeTab, setActiveTab] = useState('directory');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">药品管理</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plus className="w-4 h-4" />
          新增药品
        </button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'text-cyan-600 border-b-2 border-cyan-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'directory' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" placeholder="搜索药品名称或编码" className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
            </div>
            <select className="px-4 py-2 border border-gray-200 rounded-lg">
              <option>全部分类</option>
              <option>抗生素</option>
              <option>中成药</option>
            </select>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">编码</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">名称</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">分类</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">价格</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">库存</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                </tr>
              </thead>
              <tbody>
                {mockDrugs.map((item) => (
                  <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-600">{item.code}</td>
                    <td className="px-4 py-3 text-sm text-gray-800 font-medium">{item.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.category}</td>
                    <td className="px-4 py-3 text-sm text-cyan-600">¥{item.price}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.stock}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 text-xs rounded ${item.status === '正常' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {activeTab !== 'directory' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-gray-50 rounded-xl p-8 text-center text-gray-500">
          <Pill className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p>该功能模块正在开发中</p>
        </motion.div>
      )}
    </div>
  );
}
