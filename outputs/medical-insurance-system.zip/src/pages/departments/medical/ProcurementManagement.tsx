import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ClipboardList, Gavel, FileSignature, Truck, CreditCard } from 'lucide-react';

const tabs = [
  { id: 'plan', label: '采购计划', icon: ClipboardList },
  { id: 'bidding', label: '招标管理', icon: Gavel },
  { id: 'contract', label: '合同管理', icon: FileSignature },
  { id: 'delivery', label: '配送监管', icon: Truck },
  { id: 'settlement', label: '结算管理', icon: CreditCard }
];

const mockData = {
  plan: [
    { id: 'P001', name: '2024年药品集中采购', amount: 12500, status: '执行中', date: '2024-01' },
    { id: 'P002', name: '高值耗材采购计划', amount: 8600, status: '待审批', date: '2024-02' }
  ],
  bidding: [
    { id: 'B001', name: '抗肿瘤药品招标', type: '公开招标', status: '进行中', deadline: '2024-02-15' },
    { id: 'B002', name: '医用耗材招标', type: '邀请招标', status: '已结束', deadline: '2024-01-20' }
  ],
  contract: [
    { id: 'C001', supplier: '某制药公司', amount: 5200, status: '生效中', date: '2024-01-10' },
    { id: 'C002', supplier: '某器械公司', amount: 3800, status: '待签署', date: '2024-01-15' }
  ],
  delivery: [
    { id: 'D001', item: '阿莫西林胶囊', supplier: '某制药', qty: 10000, status: '已配送' },
    { id: 'D002', item: '心脏支架', supplier: '某器械', qty: 500, status: '配送中' }
  ],
  settlement: [
    { id: 'S001', supplier: '某制药公司', amount: 12500, status: '已结算', date: '2024-01-20' },
    { id: 'S002', supplier: '某器械公司', amount: 8600, status: '待结算', date: '-' }
  ]
};

export default function ProcurementManagement() {
  const [activeTab, setActiveTab] = useState('plan');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              {Object.keys(data[0] || {}).map(key => (
                <th key={key} className="px-4 py-3 text-left text-sm font-medium text-gray-600">{key}</th>
              ))}
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                {Object.values(item).map((val: any, idx) => (
                  <td key={idx} className="px-4 py-3 text-sm text-gray-800">{val}</td>
                ))}
                <td className="px-4 py-3">
                  <button className="text-cyan-600 text-sm hover:underline">查看</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">招标采购管理</h2>
        <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">新增计划</button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
}
