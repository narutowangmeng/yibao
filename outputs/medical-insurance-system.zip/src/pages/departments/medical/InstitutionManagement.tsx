import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Building2, FileCheck, Award, LogOut, Plus, Search, CheckCircle, XCircle } from 'lucide-react';

const tabs = [
  { id: 'access', label: '机构准入', icon: Building2 },
  { id: 'agreement', label: '协议管理', icon: FileCheck },
  { id: 'assessment', label: '机构考核', icon: Award },
  { id: 'rating', label: '等级评定', icon: Award },
  { id: 'exit', label: '退出管理', icon: LogOut }
];

const mockData = {
  access: [
    { id: 1, name: '协和医院', type: '三级甲等', status: '审核中', date: '2024-01-15' },
    { id: 2, name: '社区医疗中心', type: '一级', status: '已通过', date: '2024-01-10' }
  ],
  agreement: [
    { id: 1, name: '协和医院', expire: '2024-12-31', status: '有效' },
    { id: 2, name: '人民医院', expire: '2024-06-30', status: '即将到期' }
  ],
  assessment: [
    { id: 1, name: '协和医院', score: 95, level: '优秀' },
    { id: 2, name: '社区医疗中心', score: 82, level: '良好' }
  ],
  rating: [
    { id: 1, name: '协和医院', current: '三级甲等', apply: '特级', status: '评审中' }
  ],
  exit: [
    { id: 1, name: '某诊所', reason: '违规操作', date: '2024-01-05', status: '已退出' }
  ]
};

export default function InstitutionManagement() {
  const [activeTab, setActiveTab] = useState('access');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">医疗机构管理</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plus className="w-4 h-4" />
          新增机构
        </button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="flex gap-4 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索机构名称..." className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
        </div>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">机构名称</th>
              {activeTab === 'access' && <><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th></>}
              {activeTab === 'agreement' && <><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">到期日期</th><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th></>}
              {activeTab === 'assessment' && <><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">评分</th><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">等级</th></>}
              {activeTab === 'rating' && <><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">当前等级</th><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">申请等级</th></>}
              {activeTab === 'exit' && <><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">退出原因</th><th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th></>}
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockData[activeTab as keyof typeof mockData]?.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                {activeTab === 'access' && <><td className="px-4 py-3 text-sm text-gray-600">{item.type}</td><td className="px-4 py-3"><span className={`px-2 py-1 text-xs rounded ${item.status === '已通过' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span></td></>}
                {activeTab === 'agreement' && <><td className="px-4 py-3 text-sm text-gray-600">{item.expire}</td><td className="px-4 py-3"><span className={`px-2 py-1 text-xs rounded ${item.status === '有效' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>{item.status}</span></td></>}
                {activeTab === 'assessment' && <><td className="px-4 py-3 text-sm text-cyan-600 font-medium">{item.score}</td><td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">{item.level}</span></td></>}
                {activeTab === 'rating' && <><td className="px-4 py-3 text-sm text-gray-600">{item.current}</td><td className="px-4 py-3 text-sm text-cyan-600">{item.apply}</td></>}
                {activeTab === 'exit' && <><td className="px-4 py-3 text-sm text-gray-600">{item.reason}</td><td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded">{item.status}</span></td></>}
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button className="p-1 hover:bg-gray-200 rounded"><CheckCircle className="w-4 h-4 text-green-500" /></button>
                    <button className="p-1 hover:bg-gray-200 rounded"><XCircle className="w-4 h-4 text-red-500" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  );
}
