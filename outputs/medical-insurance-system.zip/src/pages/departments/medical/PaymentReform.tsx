import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, FileText, Wallet, Coins, Award } from 'lucide-react';

const tabs = [
  { id: 'drg', label: 'DRG/DIP管理', icon: Calculator },
  { id: 'disease', label: '按病种付费', icon: FileText },
  { id: 'global', label: '总额预付', icon: Wallet },
  { id: 'score', label: '分值付费', icon: Coins },
  { id: 'performance', label: '绩效评价', icon: Award }
];

const mockData = {
  drg: [
    { id: 1, code: 'DRG001', name: '急性心肌梗死', weight: 1.52, price: 28500 },
    { id: 2, code: 'DRG002', name: '肺炎', weight: 0.85, price: 15200 }
  ],
  disease: [
    { id: 1, disease: '阑尾炎', price: 8500, cases: 1256 },
    { id: 2, disease: '白内障', price: 6200, cases: 892 }
  ],
  global: [
    { id: 1, hospital: '市人民医院', amount: 12500, used: 11200 },
    { id: 2, hospital: '中医院', amount: 8600, used: 7800 }
  ],
  score: [
    { id: 1, item: '普通门诊', score: 12, price: 85 },
    { id: 2, item: '住院床日', score: 45, price: 320 }
  ],
  performance: [
    { id: 1, hospital: '市人民医院', score: 95, rank: 'A' },
    { id: 2, hospital: '中医院', score: 88, rank: 'B' }
  ]
};

export default function PaymentReform() {
  const [activeTab, setActiveTab] = useState('drg');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              {Object.keys(data[0] || {}).map(key => (
                <th key={key} className="px-4 py-3 text-left text-sm font-medium text-gray-600">{key}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                {Object.values(item).map((val: any, idx) => (
                  <td key={idx} className="px-4 py-3 text-sm text-gray-800">{val}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">支付方式改革</h2>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
}
