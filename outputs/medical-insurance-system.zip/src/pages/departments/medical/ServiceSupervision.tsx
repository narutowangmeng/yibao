import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Stethoscope, FileText, Pill, FlaskConical, Award } from 'lucide-react';

const tabs = [
  { id: 'behavior', label: '诊疗行为监管', icon: Stethoscope },
  { id: 'prescription', label: '处方审核', icon: FileText },
  { id: 'rational', label: '合理用药', icon: Pill },
  { id: 'inspection', label: '检查检验', icon: FlaskConical },
  { id: 'quality', label: '医疗质量', icon: Award }
];

const mockData = {
  behavior: [
    { id: 1, hospital: '市人民医院', doctor: '张医生', issue: '过度检查', status: '待处理' },
    { id: 2, hospital: '中医院', doctor: '李医生', issue: '分解收费', status: '已整改' }
  ],
  prescription: [
    { id: 1, patient: '张三', drug: '阿莫西林', qty: 2, status: '已通过' },
    { id: 2, patient: '李四', drug: '抗生素', qty: 5, status: '存疑' }
  ],
  rational: [
    { id: 1, drug: '抗生素', usage: '超剂量使用', rate: '15%', level: '高' },
    { id: 2, drug: '激素', usage: '适应症不符', rate: '8%', level: '中' }
  ],
  inspection: [
    { id: 1, item: 'CT检查', count: 1256, abnormal: 45 },
    { id: 2, item: '核磁共振', count: 856, abnormal: 23 }
  ],
  quality: [
    { id: 1, hospital: '市人民医院', score: 95, level: 'A' },
    { id: 2, hospital: '中医院', score: 88, level: 'B' }
  ]
};

export default function ServiceSupervision() {
  const [activeTab, setActiveTab] = useState('behavior');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              {Object.keys(data[0] || {}).map(key => (
                <th key={key} className="px-4 py-3 text-left text-sm font-medium text-gray-600">{key}</th>
              ))}
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                {Object.values(item).map((val: any, idx) => (
                  <td key={idx} className="px-4 py-3 text-sm text-gray-800">{val}</td>
                ))}
                <td className="px-4 py-3">
                  <button className="text-cyan-600 text-sm hover:underline">查看</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">医疗服务行为监管</h2>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
}
