import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, TrendingUp, Search, Plus, Edit, Trash2, AlertTriangle } from 'lucide-react';

const tabs = [
  { id: 'pricing', label: '价格制定', icon: DollarSign },
  { id: 'adjust', label: '价格调整', icon: TrendingUp },
  { id: 'audit', label: '成本监审', icon: Search },
  { id: 'public', label: '价格公示', icon: Plus },
  { id: 'monitor', label: '异常监测', icon: AlertTriangle }
];

const mockData = {
  pricing: [
    { id: 1, name: '普通门诊诊查费', code: 'Z001', price: 15, status: '已生效' },
    { id: 2, name: 'CT平扫', code: 'Z002', price: 280, status: '审核中' }
  ],
  adjust: [
    { id: 1, name: '床位费', oldPrice: 45, newPrice: 52, date: '2024-01-01' }
  ],
  audit: [
    { id: 1, hospital: '市人民医院', cost: 12500, status: '已通过' }
  ],
  public: [
    { id: 1, title: '2024年医疗服务价格公示', date: '2024-01-15', views: 1256 }
  ],
  monitor: [
    { id: 1, item: '手术费异常波动', level: '高', date: '2024-01-15' }
  ]
};

export default function PriceManagement() {
  const [activeTab, setActiveTab] = useState('pricing');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">医疗服务价格管理</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg">
          <Plus className="w-4 h-4" />新增
        </button>
      </div>

      <div className="flex gap-2 border-b">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-500'
              }`}
            >
              <Icon className="w-4 h-4" />{tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium">项目</th>
              <th className="px-4 py-3 text-left text-sm font-medium">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockData[activeTab as keyof typeof mockData]?.map((item: any) => (
              <tr key={item.id} className="border-t">
                <td className="px-4 py-3 text-sm">{item.name || item.title || item.hospital || item.item}</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-1 text-xs rounded bg-green-100 text-green-700">{item.status || item.level || '正常'}</span>
                </td>
                <td className="px-4 py-3 flex gap-2">
                  <button className="p-1 text-gray-400 hover:text-cyan-600"><Edit className="w-4 h-4" /></button>
                  <button className="p-1 text-gray-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  );
}
