import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Shield, Eye, Zap, AlertTriangle, FileSearch, UserCheck,
  ChevronRight, TrendingUp, Activity, CheckCircle, AlertCircle,
  BarChart3, PieChart, LineChart, ArrowLeft
} from 'lucide-react';
import { BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell } from 'recharts';
import FundMonitoring from './fund/FundMonitoring';
import FlightInspection from './fund/FlightInspection';
import SmartSupervision from './fund/SmartSupervision';
import ViolationHandling from './fund/ViolationHandling';
import CreditManagement from './fund/CreditManagement';
import ComplaintManagement from './fund/ComplaintManagement';

const modules = [
  {
    id: 'monitor',
    name: '基金监管',
    icon: Shield,
    description: '基金收支监控、风险预警',
    stats: { alert: 23, processing: 8, resolved: 156 },
    features: ['收支监控', '风险预警', '异常监测', '趋势分析', '预警处置']
  },
  {
    id: 'inspection',
    name: '飞行检查',
    icon: Eye,
    description: '现场检查、专项检查',
    stats: { planned: 12, ongoing: 3, completed: 45 },
    features: ['检查计划', '现场检查', '专项检查', '检查结果', '整改跟踪']
  },
  {
    id: 'ai',
    name: '智能监管',
    icon: Zap,
    description: '大数据监控、规则库管理',
    stats: { rules: 156, triggered: 2341, accuracy: 94.5 },
    features: ['规则库', '智能审核', '大数据监控', '模型管理', '规则配置']
  },
  {
    id: 'violation',
    name: '违规查处',
    icon: AlertTriangle,
    description: '欺诈骗保查处、违规处理',
    stats: { cases: 89, amount: 1256, punished: 67 },
    features: ['案件管理', '违规认定', '处罚执行', '案件跟踪', '统计分析']
  },
  {
    id: 'credit',
    name: '信用管理',
    icon: UserCheck,
    description: '定点机构信用评价、黑名单管理',
    stats: { rated: 1256, blacklist: 23, good: 1189 },
    features: ['信用评价', '黑名单', '红名单', '信用修复', '信用查询']
  },
  {
    id: 'complaint',
    name: '举报投诉',
    icon: FileSearch,
    description: '举报受理、奖励发放',
    stats: { received: 234, processing: 18, rewarded: 89 },
    features: ['举报受理', '线索核查', '奖励发放', '举报统计', '线索管理']
  }
];

const stats = [
  { label: '基金总收入', value: '8,256亿', change: '+12.5%', trend: 'up' },
  { label: '基金总支出', value: '6,842亿', change: '+8.3%', trend: 'up' },
  { label: '风险预警', value: '23条', change: '-15%', trend: 'down' },
  { label: '挽回损失', value: '856亿', change: '+28.6%', trend: 'up' }
];

const riskTypeData = [
  { name: '欺诈骗保', value: 35, color: '#EF4444' },
  { name: '过度医疗', value: 28, color: '#F97316' },
  { name: '资源浪费', value: 22, color: '#EAB308' },
  { name: '违规操作', value: 15, color: '#3B82F6' }
];

const monthlyData = [
  { month: '1月', detected: 45, resolved: 38 },
  { month: '2月', detected: 52, resolved: 48 },
  { month: '3月', detected: 38, resolved: 35 },
  { month: '4月', detected: 65, resolved: 58 },
  { month: '5月', detected: 48, resolved: 45 },
  { month: '6月', detected: 72, resolved: 68 }
];

export default function FundSupervision() {
  const [activeModule, setActiveModule] = useState<string | null>(null);

  const renderModuleContent = () => {
    switch (activeModule) {
      case 'monitor':
        return <FundMonitoring />;
      case 'inspection':
        return <FlightInspection />;
      case 'ai':
        return <SmartSupervision />;
      case 'violation':
        return <ViolationHandling />;
      case 'credit':
        return <CreditManagement />;
      case 'complaint':
        return <ComplaintManagement />;
      default:
        return null;
    }
  };

  if (activeModule) {
    const moduleName = modules.find(m => m.id === activeModule)?.name || '';
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveModule(null)}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            返回
          </button>
          <span className="text-gray-400">/</span>
          <span className="text-gray-800 font-medium">{moduleName}</span>
        </div>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeModule}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            {renderModuleContent()}
          </motion.div>
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">基金监管司</h1>
          <p className="text-gray-500 mt-1">负责医保基金监管、飞行检查、智能监管、违规查处等工作</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full">二级部门</span>
          <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full">38人</span>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-5 shadow-sm border border-gray-100"
          >
            <p className="text-sm text-gray-500">{stat.label}</p>
            <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
            <div className="flex items-center gap-1 mt-2">
              <TrendingUp className={`w-4 h-4 ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`} />
              <span className={`text-sm ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>{stat.change}</span>
              <span className="text-sm text-gray-400">较上月</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-red-600" />
            风险类型分布
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <RePieChart>
              <Pie
                data={riskTypeData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                dataKey="value"
              >
                {riskTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RePieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-600" />
            风险趋势
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <ReBarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="detected" fill="#EF4444" name="发现" radius={[4, 4, 0, 0]} />
              <Bar dataKey="resolved" fill="#22C55E" name="处理" radius={[4, 4, 0, 0]} />
            </ReBarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {modules.map((module, index) => {
          const Icon = module.icon;
          return (
            <motion.div
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setActiveModule(activeModule === module.id ? null : module.id)}
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-red-600" />
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
              <h3 className="font-semibold text-gray-800 mt-4">{module.name}</h3>
              <p className="text-sm text-gray-500 mt-1">{module.description}</p>
              
              <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100">
                {module.id === 'monitor' && (
                  <>
                    <div><p className="text-xs text-gray-400">预警</p><p className="text-lg font-semibold text-red-600">{module.stats.alert}</p></div>
                    <div><p className="text-xs text-gray-400">处理中</p><p className="text-lg font-semibold text-orange-500">{module.stats.processing}</p></div>
                    <div><p className="text-xs text-gray-400">已处理</p><p className="text-lg font-semibold text-green-600">{module.stats.resolved}</p></div>
                  </>
                )}
                {module.id === 'inspection' && (
                  <>
                    <div><p className="text-xs text-gray-400">计划</p><p className="text-lg font-semibold text-gray-800">{module.stats.planned}</p></div>
                    <div><p className="text-xs text-gray-400">进行中</p><p className="text-lg font-semibold text-cyan-600">{module.stats.ongoing}</p></div>
                    <div><p className="text-xs text-gray-400">已完成</p><p className="text-lg font-semibold text-green-600">{module.stats.completed}</p></div>
                  </>
                )}
                {module.id === 'ai' && (
                  <>
                    <div><p className="text-xs text-gray-400">规则数</p><p className="text-lg font-semibold text-gray-800">{module.stats.rules}</p></div>
                    <div><p className="text-xs text-gray-400">触发</p><p className="text-lg font-semibold text-cyan-600">{module.stats.triggered}</p></div>
                    <div><p className="text-xs text-gray-400">准确率</p><p className="text-lg font-semibold text-green-600">{module.stats.accuracy}%</p></div>
                  </>
                )}
                {module.id === 'violation' && (
                  <>
                    <div><p className="text-xs text-gray-400">案件</p><p className="text-lg font-semibold text-gray-800">{module.stats.cases}</p></div>
                    <div><p className="text-xs text-gray-400">金额</p><p className="text-lg font-semibold text-red-600">{module.stats.amount}万</p></div>
                    <div><p className="text-xs text-gray-400">处罚</p><p className="text-lg font-semibold text-orange-500">{module.stats.punished}</p></div>
                  </>
                )}
                {module.id === 'credit' && (
                  <>
                    <div><p className="text-xs text-gray-400">已评价</p><p className="text-lg font-semibold text-gray-800">{module.stats.rated}</p></div>
                    <div><p className="text-xs text-gray-400">黑名单</p><p className="text-lg font-semibold text-red-600">{module.stats.blacklist}</p></div>
                    <div><p className="text-xs text-gray-400">信用好</p><p className="text-lg font-semibold text-green-600">{module.stats.good}</p></div>
                  </>
                )}
                {module.id === 'complaint' && (
                  <>
                    <div><p className="text-xs text-gray-400">收到</p><p className="text-lg font-semibold text-gray-800">{module.stats.received}</p></div>
                    <div><p className="text-xs text-gray-400">处理中</p><p className="text-lg font-semibold text-orange-500">{module.stats.processing}</p></div>
                    <div><p className="text-xs text-gray-400">已奖励</p><p className="text-lg font-semibold text-green-600">{module.stats.rewarded}</p></div>
                  </>
                )}
              </div>

              {activeModule === module.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="mt-4 pt-4 border-t border-gray-100"
                >
                  <p className="text-sm font-medium text-gray-700 mb-2">功能列表</p>
                  <div className="space-y-2">
                    {module.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-red-500" />
                        {feature}
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-red-600" />
          风险预警
        </h3>
        <div className="space-y-3">
          {[
            { level: 'critical', title: '某医院报销异常增长320%', desc: '本月报销金额较上月增长320%，存在虚假住院嫌疑', amount: '125万' },
            { level: 'high', title: '个人账户频繁大额消费', desc: '检测到3个账户存在异常消费模式，疑似套现行为', amount: '8.5万' },
            { level: 'medium', title: '药品使用异常', desc: '某医生抗生素使用频率高于科室平均水平200%', amount: '1.2万' }
          ].map((item, idx) => (
            <div key={idx} className={`flex items-center gap-4 p-3 rounded-lg ${
              item.level === 'critical' ? 'bg-red-50 border-l-4 border-red-500' :
              item.level === 'high' ? 'bg-orange-50 border-l-4 border-orange-500' :
              'bg-yellow-50 border-l-4 border-yellow-500'
            }`}>
              <AlertTriangle className={`w-5 h-5 ${
                item.level === 'critical' ? 'text-red-600' :
                item.level === 'high' ? 'text-orange-600' :
                'text-yellow-600'
              }`} />
              <div className="flex-1">
                <p className="font-medium text-gray-800">{item.title}</p>
                <p className="text-sm text-gray-500">{item.desc}</p>
              </div>
              <span className="text-sm font-semibold text-red-600">¥{item.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
