import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, FileText, AlertTriangle, CheckCircle, Archive, BookOpen } from 'lucide-react';

const tabs = [
  { id: 'clues', label: '违规线索', icon: AlertTriangle },
  { id: 'investigation', label: '案件调查', icon: Search },
  { id: 'penalty', label: '处罚决定', icon: FileText },
  { id: 'archive', label: '案件归档', icon: Archive },
  { id: 'cases', label: '典型案例', icon: BookOpen }
];

const mockData = {
  clues: [
    { id: 'C001', source: '举报', content: '某医院虚开药品', status: '待核实', date: '2024-01-15' },
    { id: 'C002', source: '智能监控', content: '异常报销行为', status: '已受理', date: '2024-01-14' }
  ],
  investigation: [
    { id: 'I001', subject: '某药店', type: '欺诈骗保', status: '调查中', officer: '王警官' },
    { id: 'I002', subject: '某医院', type: '违规收费', status: '待立案', officer: '李警官' }
  ],
  penalty: [
    { id: 'P001', subject: '某诊所', violation: '超范围执业', penalty: '罚款5万', status: '已生效' }
  ],
  archive: [
    { id: 'A001', caseNo: '2024-001', name: '某医院骗保案', date: '2024-01-10', status: '已归档' }
  ],
  cases: [
    { id: 'T001', title: '某医院虚构医疗服务骗保案', amount: '120万', result: '追回基金并处罚' }
  ]
};

export default function ViolationHandling() {
  const [activeTab, setActiveTab] = useState('clues');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">编号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">内容/对象</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">日期</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-600">{item.id}</td>
                <td className="px-4 py-3 text-sm text-gray-800">{item.content || item.subject || item.name || item.title}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${item.status === '已生效' || item.status === '已归档' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {item.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">{item.date || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">违规查处</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
          <AlertTriangle className="w-4 h-4" />
          新增线索
        </button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-red-600 border-b-2 border-red-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
}
