import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, FileText, AlertTriangle, RefreshCw, Globe, Search, Filter } from 'lucide-react';

const tabs = [
  { id: 'evaluation', label: '信用评价', icon: Star },
  { id: 'archive', label: '信用档案', icon: FileText },
  { id: 'punishment', label: '失信惩戒', icon: AlertTriangle },
  { id: 'repair', label: '信用修复', icon: RefreshCw },
  { id: 'publicity', label: '信用公示', icon: Globe }
];

const mockData = {
  evaluation: [
    { id: 1, name: '某医院', score: 95, level: 'A级', date: '2024-01' },
    { id: 2, name: '某药店', score: 82, level: 'B级', date: '2024-01' },
    { id: 3, name: '某诊所', score: 65, level: 'C级', date: '2024-01' }
  ],
  archive: [
    { id: 1, name: '某医院', type: '医疗机构', records: 12, status: '正常' },
    { id: 2, name: '某药店', type: '零售药店', records: 5, status: '正常' }
  ],
  punishment: [
    { id: 1, name: '某诊所', reason: '欺诈骗保', measure: '暂停结算', date: '2024-01-15' },
    { id: 2, name: '某药店', reason: '违规刷卡', measure: '罚款2万', date: '2024-01-10' }
  ],
  repair: [
    { id: 1, name: '某药店', applyDate: '2024-01-20', status: '审核中' },
    { id: 2, name: '某诊所', applyDate: '2024-01-18', status: '已通过' }
  ],
  publicity: [
    { id: 1, title: '2024年第一期信用评价结果', date: '2024-01-15', views: 1256 },
    { id: 2, title: '失信惩戒名单公示', date: '2024-01-10', views: 892 }
  ]
};

export default function CreditManagement() {
  const [activeTab, setActiveTab] = useState('evaluation');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="space-y-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" placeholder="搜索..." className="w-full pl-10 pr-4 py-2 border rounded-lg" />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
            <Filter className="w-4 h-4" />筛选
          </button>
        </div>
        <div className="bg-white rounded-lg border">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                {activeTab === 'evaluation' && <><th className="p-3 text-left">机构名称</th><th className="p-3">信用评分</th><th className="p-3">信用等级</th><th className="p-3">评价日期</th></>}
                {activeTab === 'archive' && <><th className="p-3 text-left">机构名称</th><th className="p-3">机构类型</th><th className="p-3">档案记录</th><th className="p-3">状态</th></>}
                {activeTab === 'punishment' && <><th className="p-3 text-left">机构名称</th><th className="p-3">失信原因</th><th className="p-3">惩戒措施</th><th className="p-3">惩戒日期</th></>}
                {activeTab === 'repair' && <><th className="p-3 text-left">机构名称</th><th className="p-3">申请日期</th><th className="p-3">审核状态</th></>}
                {activeTab === 'publicity' && <><th className="p-3 text-left">公示标题</th><th className="p-3">发布日期</th><th className="p-3">浏览量</th></>}
              </tr>
            </thead>
            <tbody>
              {data.map((item: any) => (
                <tr key={item.id} className="border-t hover:bg-gray-50">
                  <td className="p-3">{item.name || item.title}</td>
                  {item.score && <td className="p-3 text-center text-cyan-600 font-medium">{item.score}</td>}
                  {item.level && <td className="p-3 text-center"><span className={`px-2 py-1 rounded text-xs ${item.level === 'A级' ? 'bg-green-100 text-green-700' : item.level === 'B级' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>{item.level}</span></td>}
                  {item.type && <td className="p-3 text-center text-gray-600">{item.type}</td>}
                  {item.records && <td className="p-3 text-center">{item.records}条</td>}
                  {item.reason && <td className="p-3 text-center text-red-600">{item.reason}</td>}
                  {item.measure && <td className="p-3 text-center">{item.measure}</td>}
                  {item.applyDate && <td className="p-3 text-center">{item.applyDate}</td>}
                  {item.status && <td className="p-3 text-center"><span className={`px-2 py-1 rounded text-xs ${item.status === '正常' || item.status === '已通过' ? 'bg-green-100 text-green-700' : item.status === '审核中' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></td>}
                  {item.date && <td className="p-3 text-center text-gray-600">{item.date}</td>}
                  {item.views && <td className="p-3 text-center text-gray-600">{item.views}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 border-b">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'}`}
            >
              <Icon className="w-4 h-4" />{tab.label}
            </button>
          );
        })}
      </div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>{renderContent()}</motion.div>
    </div>
  );
}
