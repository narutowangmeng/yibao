import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, AlertTriangle, BarChart3, FileText, Activity } from 'lucide-react';

const tabs = [
  { id: 'monitor', label: '基金收支监控', icon: TrendingUp },
  { id: 'warning', label: '风险预警', icon: AlertTriangle },
  { id: 'analysis', label: '基金运行分析', icon: BarChart3 },
  { id: 'report', label: '基金报表', icon: FileText },
  { id: 'anomaly', label: '异常数据检测', icon: Activity }
];

const mockData = {
  income: { current: 8256, last: 7600, trend: '+8.6%' },
  expense: { current: 6842, last: 6100, trend: '+12.1%' },
  balance: { current: 1414, last: 1500, trend: '-5.7%' }
};

export default function FundMonitoring() {
  const [activeTab, setActiveTab] = useState('monitor');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">基金监管</h2>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'monitor' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-xl border border-gray-200">
              <p className="text-sm text-gray-500">本月基金收入</p>
              <p className="text-2xl font-bold text-green-600">{mockData.income.current}万</p>
              <p className="text-sm text-green-500">{mockData.income.trend} 环比</p>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200">
              <p className="text-sm text-gray-500">本月基金支出</p>
              <p className="text-2xl font-bold text-orange-600">{mockData.expense.current}万</p>
              <p className="text-sm text-orange-500">{mockData.expense.trend} 环比</p>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200">
              <p className="text-sm text-gray-500">基金结余</p>
              <p className="text-2xl font-bold text-cyan-600">{mockData.balance.current}万</p>
              <p className="text-sm text-red-500">{mockData.balance.trend} 环比</p>
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === 'warning' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-xl p-4">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-medium">高风险预警</span>
            </div>
            <p className="text-sm text-red-600 mt-2">某医院门诊费用异常增长，超出正常范围120%</p>
          </div>
        </motion.div>
      )}

      {activeTab === 'analysis' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-800 mb-4">基金运行趋势</h3>
          <div className="h-40 flex items-end gap-2">
            {[60, 75, 82, 78, 85, 90, 88, 92, 95, 90, 94, 98].map((h, i) => (
              <div key={i} className="flex-1 bg-cyan-500 rounded-t" style={{ height: `${h}%` }} />
            ))}
          </div>
        </motion.div>
      )}

      {activeTab === 'report' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报表名称</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">生成日期</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-gray-100">
                <td className="px-4 py-3 text-sm text-gray-800">2024年1月基金收支报表</td>
                <td className="px-4 py-3 text-sm text-gray-600">2024-02-01</td>
                <td className="px-4 py-3 text-sm text-cyan-600 cursor-pointer">下载</td>
              </tr>
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'anomaly' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <p className="text-sm text-gray-600">检测到3条异常数据，请人工复核</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
