import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, MessageSquare, Search, CheckCircle, Clock, BarChart3 } from 'lucide-react';

const tabs = [
  { id: 'accept', label: '举报受理', icon: Phone },
  { id: 'handle', label: '投诉处理', icon: MessageSquare },
  { id: 'verify', label: '线索核查', icon: Search },
  { id: 'reply', label: '反馈回复', icon: CheckCircle },
  { id: 'stats', label: '统计分析', icon: BarChart3 }
];

const mockData = {
  accept: [
    { id: 'JB001', type: '欺诈骗保', content: '某医院虚开药品', status: '待受理', date: '2024-01-15' },
    { id: 'JB002', type: '违规收费', content: '某诊所超标准收费', status: '已受理', date: '2024-01-14' }
  ],
  handle: [
    { id: 'TS001', complainant: '张三', content: '报销被拒', status: '处理中', date: '2024-01-13' }
  ],
  verify: [
    { id: 'XS001', clue: '异常住院数据', source: '智能监控', status: '核查中', date: '2024-01-12' }
  ],
  reply: [
    { id: 'FK001', title: '投诉处理结果', recipient: '李四', status: '已回复', date: '2024-01-11' }
  ]
};

export default function ComplaintManagement() {
  const [activeTab, setActiveTab] = useState('accept');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="space-y-4">
        <div className="flex gap-4">
          <input type="text" placeholder="搜索关键词..." className="flex-1 px-4 py-2 border rounded-lg" />
          <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg">查询</button>
        </div>
        <div className="bg-white rounded-lg border overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">编号</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型/内容</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">日期</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item: any) => (
                <tr key={item.id} className="border-t hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.id}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.content || item.clue || item.title}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded ${item.status === '已受理' || item.status === '已回复' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">{item.date}</td>
                  <td className="px-4 py-3">
                    <button className="text-cyan-600 text-sm hover:underline">处理</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">举报投诉管理</h2>
      </div>
      <div className="flex gap-2 border-b">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'}`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {activeTab === 'stats' ? (
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">本月受理</p><p className="text-2xl font-bold text-cyan-600">156</p></div>
            <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">已办结</p><p className="text-2xl font-bold text-green-600">142</p></div>
            <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">办结率</p><p className="text-2xl font-bold text-blue-600">91%</p></div>
          </div>
        ) : renderContent()}
      </motion.div>
    </div>
  );
}
