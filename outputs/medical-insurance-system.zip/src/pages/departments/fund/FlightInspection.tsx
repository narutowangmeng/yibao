import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plane, Calendar, Users, ClipboardCheck, AlertCircle, CheckCircle } from 'lucide-react';

const tabs = [
  { id: 'plan', label: '检查计划', icon: Calendar },
  { id: 'assign', label: '任务分配', icon: Users },
  { id: 'record', label: '检查记录', icon: ClipboardCheck },
  { id: 'result', label: '结果处理', icon: AlertCircle },
  { id: 'track', label: '整改跟踪', icon: CheckCircle }
];

const mockData = {
  plan: [
    { id: 'P001', name: '2024年Q1飞行检查', date: '2024-03-15', status: '进行中' },
    { id: 'P002', name: '定点医疗机构专项检查', date: '2024-02-20', status: '已完成' }
  ],
  assign: [
    { id: 'T001', inspector: '张检查员', target: '某三甲医院', date: '2024-03-10', status: '已分配' },
    { id: 'T002', inspector: '李检查员', target: '某社区医院', date: '2024-03-12', status: '待分配' }
  ],
  record: [
    { id: 'R001', hospital: '某三甲医院', date: '2024-03-10', issues: 3, status: '已记录' },
    { id: 'R002', hospital: '某药店', date: '2024-03-11', issues: 1, status: '已记录' }
  ],
  result: [
    { id: 'RS001', hospital: '某三甲医院', result: '违规', amount: 125000, status: '待处理' },
    { id: 'RS002', hospital: '某药店', result: '合规', amount: 0, status: '已归档' }
  ],
  track: [
    { id: 'TR001', hospital: '某三甲医院', issue: '过度医疗', deadline: '2024-04-15', status: '整改中' },
    { id: 'TR002', hospital: '某药店', issue: '处方不规范', deadline: '2024-03-30', status: '已整改' }
  ]
};

export default function FlightInspection() {
  const [activeTab, setActiveTab] = useState('plan');

  const renderContent = () => {
    const data = mockData[activeTab as keyof typeof mockData] || [];
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">编号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">名称/对象</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">日期</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-600">{item.id}</td>
                <td className="px-4 py-3 text-sm text-gray-800">{item.name || item.hospital || item.target}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.date || item.deadline}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${
                    item.status === '已完成' || item.status === '已整改' ? 'bg-green-100 text-green-700' :
                    item.status === '进行中' || item.status === '整改中' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>{item.status}</span>
                </td>
                <td className="px-4 py-3">
                  <button className="text-cyan-600 text-sm hover:underline">查看</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">飞行检查</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plane className="w-4 h-4" />
          新增检查
        </button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
}
