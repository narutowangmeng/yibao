import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, AlertTriangle, Search, Settings, Cpu, TrendingUp } from 'lucide-react';

const tabs = [
  { id: 'risk', label: '智能风控', icon: Brain },
  { id: 'anomaly', label: '异常识别', icon: AlertTriangle },
  { id: 'mining', label: '数据挖掘', icon: Search },
  { id: 'rules', label: '预警规则', icon: Settings },
  { id: 'ai', label: 'AI决策', icon: Cpu }
];

const mockAlerts = [
  { id: 1, type: '高频就诊', level: 'high', desc: '某参保人30天内就诊12次', time: '10:30' },
  { id: 2, type: '异常用药', level: 'medium', desc: '某医院抗生素使用超标', time: '09:15' }
];

export default function SmartSupervision() {
  const [activeTab, setActiveTab] = useState('risk');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">智能监管</h2>
        <span className="text-sm text-gray-500">基金监管司 / 智能监管</span>
      </div>

      <div className="flex gap-2 bg-white p-2 rounded-lg border border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'bg-red-500 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'risk' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-xl border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-3">风控模型运行状态</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm"><span>就诊行为模型</span><span className="text-green-600">运行中</span></div>
              <div className="flex justify-between text-sm"><span>费用异常模型</span><span className="text-green-600">运行中</span></div>
              <div className="flex justify-between text-sm"><span>药品使用模型</span><span className="text-green-600">运行中</span></div>
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-3">今日预警</h3>
            <p className="text-3xl font-bold text-red-600">24</p>
            <p className="text-sm text-gray-500">较昨日 +5</p>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-3">模型准确率</h3>
            <p className="text-3xl font-bold text-blue-600">96.8%</p>
            <p className="text-sm text-gray-500">本月平均</p>
          </div>
        </motion.div>
      )}

      {activeTab === 'anomaly' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200">
          <div className="p-4 border-b border-gray-100">
            <h3 className="font-medium text-gray-800">异常行为识别</h3>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">描述</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">等级</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">时间</th>
              </tr>
            </thead>
            <tbody>
              {mockAlerts.map(item => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.type}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.desc}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded ${item.level === 'high' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'}`}>
                      {item.level === 'high' ? '高风险' : '中风险'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">{item.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'mining' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-xl border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-4">数据挖掘分析</h3>
            <div className="space-y-3">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-700">关联规则挖掘</p>
                <p className="text-xs text-gray-500">发现3组异常用药组合</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-700">聚类分析</p>
                <p className="text-xs text-gray-500">识别2个可疑就诊群体</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200">
            <h3 className="font-medium text-gray-800 mb-4">分析任务</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm"><div className="w-2 h-2 bg-green-500 rounded-full"></div><span>月度费用分析 - 已完成</span></div>
              <div className="flex items-center gap-2 text-sm"><div className="w-2 h-2 bg-blue-500 rounded-full"></div><span>就诊行为分析 - 进行中</span></div>
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === 'rules' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-4">预警规则配置</h3>
          <div className="space-y-3">
            {['单日就诊次数超过3次', '月度费用超过平均值200%', '同一药品重复开具'].map((rule, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <span className="text-sm text-gray-700">{rule}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:ring-2 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
                </label>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {activeTab === 'ai' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-4">AI辅助决策</h3>
          <div className="p-4 bg-blue-50 rounded-lg mb-4">
            <p className="text-sm text-blue-800">系统建议：对近期高频就诊的5家医疗机构进行重点核查</p>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">采纳建议</button>
            <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm">忽略</button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
