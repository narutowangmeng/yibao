import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, FileText, Calculator, ChevronRight, Plus, Search, Edit, Trash2 } from 'lucide-react';

const standards = [
  { id: 1, name: '职工基本医疗保险', type: '住院', rate: '85%', cap: '50万', status: '生效中' },
  { id: 2, name: '城乡居民基本医疗保险', type: '住院', rate: '70%', cap: '30万', status: '生效中' },
  { id: 3, name: '门诊统筹', type: '门诊', rate: '60%', cap: '2000元', status: '生效中' },
];

const policies = [
  { id: 1, title: '关于调整医保待遇标准的通知', date: '2024-01-15', status: '已发布' },
  { id: 2, title: '门诊共济保障机制实施方案', date: '2024-02-20', status: '已发布' },
];

const adjustments = [
  { id: 1, item: '住院报销比例', oldValue: '80%', newValue: '85%', date: '2024-01-01' },
  { id: 2, item: '门诊年度限额', oldValue: '1500元', newValue: '2000元', date: '2024-01-01' },
];

export default function BenefitPolicy() {
  const [activeTab, setActiveTab] = useState('standards');
  const [showCalc, setShowCalc] = useState(false);
  const [calcResult, setCalcResult] = useState<any>(null);

  const tabs = [
    { id: 'standards', label: '待遇标准', icon: Shield },
    { id: 'policies', label: '政策文件', icon: FileText },
    { id: 'adjustments', label: '调整记录', icon: Edit },
    { id: 'calculator', label: '待遇测算', icon: Calculator },
  ];

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    setCalcResult({ total: 50000, reimbursement: 42500, selfPay: 7500 });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">待遇政策管理</h1>
          <p className="text-gray-500 mt-1">医保待遇标准制定、政策管理与待遇测算</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plus className="w-4 h-4" />
          新增政策
        </button>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'text-cyan-600 border-b-2 border-cyan-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'standards' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-4 border-b border-gray-100 flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input type="text" placeholder="搜索待遇标准..." className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm" />
            </div>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">待遇名称</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报销比例</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">年度限额</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
              </tr>
            </thead>
            <tbody>
              {standards.map((item) => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                  <td className="px-4 py-3 text-sm text-cyan-600 font-medium">{item.rate}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.cap}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">{item.status}</span></td>
                  <td className="px-4 py-3 flex gap-2">
                    <button className="p-1 text-gray-400 hover:text-cyan-600"><Edit className="w-4 h-4" /></button>
                    <button className="p-1 text-gray-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'policies' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          {policies.map((policy) => (
            <div key={policy.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-50 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-cyan-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800">{policy.title}</h3>
                  <p className="text-sm text-gray-500">发布日期: {policy.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full">{policy.status}</span>
                <button className="p-2 text-gray-400 hover:text-cyan-600"><ChevronRight className="w-5 h-5" /></button>
              </div>
            </div>
          ))}
        </motion.div>
      )}

      {activeTab === 'adjustments' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl shadow-sm border border-gray-100">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">调整项目</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">原标准</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">新标准</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">生效日期</th>
              </tr>
            </thead>
            <tbody>
              {adjustments.map((item) => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.item}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{item.oldValue}</td>
                  <td className="px-4 py-3 text-sm text-cyan-600 font-medium">{item.newValue}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'calculator' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-2 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-semibold text-gray-800 mb-4">待遇测算工具</h3>
            <form onSubmit={handleCalculate} className="space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">参保类型</label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>职工基本医疗保险</option>
                  <option>城乡居民基本医疗保险</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">医疗费用总额</label>
                <input type="number" placeholder="请输入金额" className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">就医类型</label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>住院</option>
                  <option>门诊</option>
                </select>
              </div>
              <button type="submit" className="w-full py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">开始测算</button>
            </form>
          </div>
          {calcResult && (
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-800 mb-4">测算结果</h3>
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">医疗费用总额</p>
                  <p className="text-2xl font-bold text-gray-800">¥{calcResult.total.toLocaleString()}</p>
                </div>
                <div className="p-4 bg-cyan-50 rounded-lg">
                  <p className="text-sm text-cyan-600">医保报销金额</p>
                  <p className="text-2xl font-bold text-cyan-700">¥{calcResult.reimbursement.toLocaleString()}</p>
                </div>
                <div className="p-4 bg-orange-50 rounded-lg">
                  <p className="text-sm text-orange-600">个人自付金额</p>
                  <p className="text-2xl font-bold text-orange-700">¥{calcResult.selfPay.toLocaleString()}</p>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}
