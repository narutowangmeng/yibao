import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Search, Filter, Plus, Edit2, ArrowRightLeft, FileText } from 'lucide-react';

const mockData = [
  { id: '1', name: '张三', type: '个人', status: '正常', date: '2024-01-15', region: '北京市' },
  { id: '2', name: 'ABC科技有限公司', type: '单位', status: '正常', date: '2024-02-20', region: '上海市' },
  { id: '3', name: '李四', type: '个人', status: '暂停', date: '2023-12-10', region: '广州市' },
];

export default function EnrollmentManagement() {
  const [activeTab, setActiveTab] = useState('register');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'register', label: '参保登记', icon: Plus },
    { id: 'change', label: '信息变更', icon: Edit2 },
    { id: 'transfer', label: '关系转移', icon: ArrowRightLeft },
    { id: 'query', label: '参保查询', icon: Search },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">参保管理</h2>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plus className="w-4 h-4" />
          新增登记
        </button>
      </div>

      <div className="flex gap-2 bg-white p-2 rounded-lg border border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                activeTab === tab.id ? 'bg-cyan-100 text-cyan-700' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'register' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm text-gray-600 mb-1">参保类型</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                <option>个人参保</option>
                <option>单位参保</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">姓名/单位名称</label>
              <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="请输入" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">身份证号/统一社会信用代码</label>
              <input type="text" className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="请输入" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">参保地区</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                <option>北京市</option>
                <option>上海市</option>
                <option>广州市</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">重置</button>
            <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">提交登记</button>
          </div>
        </motion.div>
      )}

      {activeTab === 'query' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <div className="flex gap-4 bg-white p-4 rounded-xl border border-gray-200">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
                placeholder="搜索姓名、身份证号..."
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Filter className="w-4 h-4" />
              筛选
            </button>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保编号</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名/单位</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保日期</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">地区</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody>
                {mockData.map((item) => (
                  <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-800">{item.id}</td>
                    <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`px-2 py-1 rounded text-xs ${item.type === '个人' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                        {item.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`px-2 py-1 rounded text-xs ${item.status === '正常' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.date}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.region}</td>
                    <td className="px-4 py-3 text-sm">
                      <button className="text-cyan-600 hover:text-cyan-700">查看</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {(activeTab === 'change' || activeTab === 'transfer') && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="text-center py-12 text-gray-500">
            <FileText className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>请选择左侧菜单进入对应功能</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
