import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Bell, Search, AlertTriangle, BarChart3, CheckCircle, XCircle } from 'lucide-react';

const tabs = [
  { id: 'assess', label: '缴费核定', icon: CreditCard },
  { id: 'notice', label: '催缴通知', icon: Bell },
  { id: 'record', label: '缴费记录', icon: Search },
  { id: 'arrear', label: '欠费处理', icon: AlertTriangle },
  { id: 'stats', label: '缴费统计', icon: BarChart3 }
];

const mockRecords = [
  { id: 1, name: '张三', type: '个人', amount: 520, status: '已缴费', date: '2024-01-15' },
  { id: 2, name: '某科技公司', type: '单位', amount: 15800, status: '已缴费', date: '2024-01-14' },
  { id: 3, name: '李四', type: '个人', amount: 520, status: '欠费', date: '-' },
  { id: 4, name: '某制造企业', type: '单位', amount: 42300, status: '待核定', date: '-' }
];

const mockNotices = [
  { id: 1, target: '某贸易公司', amount: 25600, days: 15, status: '已发送' },
  { id: 2, target: '王五', amount: 1040, days: 8, status: '待发送' },
  { id: 3, target: '某餐饮公司', amount: 8900, days: 22, status: '已逾期' }
];

export default function PaymentManagement() {
  const [activeTab, setActiveTab] = useState('assess');
  const [calcResult, setCalcResult] = useState<number | null>(null);

  const calculate = (base: number, rate: number) => {
    setCalcResult(base * rate * 12);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">缴费管理</h2>
        <span className="text-sm text-gray-500">待遇保障司 / 缴费管理</span>
      </div>

      <div className="flex gap-2 bg-white p-2 rounded-lg border border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id ? 'bg-cyan-500 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'assess' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-800 mb-4">缴费核定计算</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <input type="number" placeholder="缴费基数" className="px-4 py-2 border border-gray-300 rounded-lg" onChange={e => calculate(Number(e.target.value), 0.08)} />
            <input type="number" placeholder="费率(如0.08)" className="px-4 py-2 border border-gray-300 rounded-lg" defaultValue="0.08" />
            <div className="px-4 py-2 bg-gray-50 rounded-lg text-gray-700">年缴费: {calcResult?.toFixed(2) || '-'} 元</div>
          </div>
          <button className="px-6 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600">确认核定</button>
        </motion.div>
      )}

      {activeTab === 'notice' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">欠费对象</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">欠费金额</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">逾期天数</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
              </tr>
            </thead>
            <tbody>
              {mockNotices.map(item => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.target}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.amount}元</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.days}天</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded ${item.status === '已逾期' ? 'bg-red-100 text-red-600' : item.status === '已发送' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>{item.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    {item.status === '待发送' && <button className="text-sm text-cyan-600 hover:underline">发送通知</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'record' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200">
          <div className="p-4 border-b border-gray-100 flex gap-4">
            <input type="text" placeholder="搜索姓名/单位" className="px-4 py-2 border border-gray-300 rounded-lg text-sm" />
            <select className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
              <option>全部状态</option>
              <option>已缴费</option>
              <option>欠费</option>
            </select>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">名称</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">金额</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费日期</th>
              </tr>
            </thead>
            <tbody>
              {mockRecords.map(item => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.amount}元</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs rounded ${item.status === '已缴费' ? 'bg-green-100 text-green-600' : item.status === '欠费' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'}`}>{item.status}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">{item.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'arrear' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 border border-gray-200">
          <h3 className="font-semibold text-gray-800 mb-4">欠费处理流程</h3>
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-cyan-500 text-white flex items-center justify-center text-sm">1</div><span className="text-sm text-gray-600">识别欠费</span></div>
            <div className="w-8 h-px bg-gray-300"></div>
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center text-sm">2</div><span className="text-sm text-gray-600">发送催缴</span></div>
            <div className="w-8 h-px bg-gray-300"></div>
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center text-sm">3</div><span className="text-sm text-gray-600">限期补缴</span></div>
            <div className="w-8 h-px bg-gray-300"></div>
            <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center text-sm">4</div><span className="text-sm text-gray-600">逾期处理</span></div>
          </div>
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg"><CheckCircle className="w-4 h-4" /> 标记已补缴</button>
            <button className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg"><XCircle className="w-4 h-4" /> 启动追缴</button>
          </div>
        </motion.div>
      )}

      {activeTab === 'stats' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <h3 className="font-semibold text-gray-800 mb-4">月度缴费趋势</h3>
            <div className="h-32 flex items-end gap-2">
              {[65, 78, 82, 75, 88, 92, 85, 90, 95, 88, 92, 98].map((h, i) => (
                <div key={i} className="flex-1 bg-cyan-500 rounded-t" style={{ height: `${h}%` }}></div>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              <span>1月</span><span>6月</span><span>12月</span>
            </div>
          </div>
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <h3 className="font-semibold text-gray-800 mb-4">缴费类型分布</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2"><div className="w-4 h-4 bg-cyan-500 rounded"></div><span className="text-sm text-gray-600 flex-1">单位缴费</span><span className="text-sm font-medium">68%</span></div>
              <div className="flex items-center gap-2"><div className="w-4 h-4 bg-cyan-300 rounded"></div><span className="text-sm text-gray-600 flex-1">个人缴费</span><span className="text-sm font-medium">32%</span></div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
