import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Plus, Edit, Trash2, FileText, Pill, Stethoscope, Package } from 'lucide-react';

const tabs = [
  { id: 'drugs', label: '药品目录', icon: Pill },
  { id: 'services', label: '诊疗项目', icon: Stethoscope },
  { id: 'materials', label: '医用耗材', icon: Package },
];

const mockData = {
  drugs: [
    { id: 1, code: 'YB001', name: '阿莫西林胶囊', category: '西药', type: '甲类', price: 12.5, status: '正常' },
    { id: 2, code: 'YB002', name: '布洛芬缓释片', category: '西药', type: '乙类', price: 28.0, status: '正常' },
    { id: 3, code: 'YB003', name: '连花清瘟胶囊', category: '中成药', type: '甲类', price: 35.0, status: '调整中' },
  ],
  services: [
    { id: 1, code: 'ZL001', name: '普通门诊诊查费', category: '诊查费', type: '甲类', price: 15.0, status: '正常' },
    { id: 2, code: 'ZL002', name: 'CT平扫', category: '检查费', type: '乙类', price: 280.0, status: '正常' },
  ],
  materials: [
    { id: 1, code: 'HC001', name: '一次性输液器', category: '耗材', type: '甲类', price: 3.5, status: '正常' },
    { id: 2, code: 'HC002', name: '心脏支架', category: '高值耗材', type: '乙类', price: 8500.0, status: '正常' },
  ],
};

export default function InsuranceDirectory() {
  const [activeTab, setActiveTab] = useState('drugs');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdjustModal, setShowAdjustModal] = useState(false);

  const currentData = mockData[activeTab as keyof typeof mockData] || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">医保目录管理</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setShowAdjustModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors"
          >
            <FileText className="w-4 h-4" />
            目录调整申请
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <Plus className="w-4 h-4" />
            新增项目
          </button>
        </div>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'text-cyan-600 border-b-2 border-cyan-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="搜索编码、名称..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Filter className="w-4 h-4" />
          筛选
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">编码</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">名称</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">分类</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">价格</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {currentData.map((item) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-600">{item.code}</td>
                <td className="px-4 py-3 text-sm text-gray-800 font-medium">{item.name}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.category}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${
                    item.type === '甲类' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {item.type}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600">¥{item.price}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${
                    item.status === '正常' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {item.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button className="p-1 hover:bg-gray-200 rounded">
                      <Edit className="w-4 h-4 text-gray-500" />
                    </button>
                    <button className="p-1 hover:bg-gray-200 rounded">
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAdjustModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="bg-white rounded-xl p-6 w-96"
          >
            <h3 className="text-lg font-bold text-gray-800 mb-4">目录调整申请</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">调整类型</label>
                <select className="w-full px-3 py-2 border border-gray-200 rounded-lg">
                  <option>新增项目</option>
                  <option>价格调整</option>
                  <option>删除项目</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">项目名称</label>
                <input type="text" className="w-full px-3 py-2 border border-gray-200 rounded-lg" />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">调整原因</label>
                <textarea className="w-full px-3 py-2 border border-gray-200 rounded-lg h-20" />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button
                onClick={() => setShowAdjustModal(false)}
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                取消
              </button>
              <button
                onClick={() => setShowAdjustModal(false)}
                className="flex-1 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700"
              >
                提交申请
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
