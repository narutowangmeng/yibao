import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, FileText, CheckCircle, Clock, AlertCircle, User, Calendar, DollarSign } from 'lucide-react';

const tabs = [
  { id: 'assessment', label: '失能评估申请', icon: FileText },
  { id: 'service', label: '护理服务管理', icon: Clock },
  { id: 'institutions', label: '护理机构列表', icon: User },
  { id: 'payment', label: '待遇支付记录', icon: DollarSign },
  { id: 'query', label: '评估查询', icon: Search }
];

const mockData = {
  assessment: [
    { id: 'A001', name: '张三', age: 78, status: '待评估', date: '2024-01-15' },
    { id: 'A002', name: '李四', age: 82, status: '已通过', date: '2024-01-14' },
    { id: 'A003', name: '王五', age: 75, status: '评估中', date: '2024-01-13' }
  ],
  service: [
    { id: 'S001', name: '张三', service: '日常护理', date: '2024-01-15', status: '进行中' },
    { id: 'S002', name: '李四', service: '康复护理', date: '2024-01-14', status: '已完成' }
  ],
  institutions: [
    { id: 'I001', name: '阳光护理院', type: '定点机构', beds: 120, rating: 4.8 },
    { id: 'I002', name: '康乐养老中心', type: '定点机构', beds: 80, rating: 4.5 }
  ],
  payment: [
    { id: 'P001', name: '张三', amount: 2800, month: '2024-01', status: '已发放' },
    { id: 'P002', name: '李四', amount: 3200, month: '2024-01', status: '已发放' }
  ]
};

export default function LongTermCare() {
  const [activeTab, setActiveTab] = useState('assessment');
  const [searchTerm, setSearchTerm] = useState('');

  const renderContent = () => {
    switch (activeTab) {
      case 'assessment':
        return (
          <div className="space-y-4">
            <div className="flex gap-4 mb-4">
              <div className="flex-1 relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索申请人姓名或编号"
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
                <Plus className="w-4 h-4" />
                新增申请
              </button>
            </div>
            <div className="bg-white rounded-lg border border-gray-200">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">申请编号</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">年龄</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">申请日期</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {mockData.assessment.map((item) => (
                    <tr key={item.id} className="border-t border-gray-100">
                      <td className="px-4 py-3 text-sm text-gray-800">{item.id}</td>
                      <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.age}岁</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.date}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          item.status === '已通过' ? 'bg-green-100 text-green-700' :
                          item.status === '待评估' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>{item.status}</span>
                      </td>
                      <td className="px-4 py-3">
                        <button className="text-cyan-600 text-sm hover:underline">查看详情</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'service':
        return (
          <div className="grid grid-cols-2 gap-4">
            {mockData.service.map((item) => (
              <div key={item.id} className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-gray-800">{item.name}</h4>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    item.status === '已完成' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                  }`}>{item.status}</span>
                </div>
                <p className="text-sm text-gray-600 mb-2">服务类型: {item.service}</p>
                <p className="text-sm text-gray-500">服务日期: {item.date}</p>
              </div>
            ))}
          </div>
        );
      case 'institutions':
        return (
          <div className="grid grid-cols-2 gap-4">
            {mockData.institutions.map((item) => (
              <div key={item.id} className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium text-gray-800">{item.name}</h4>
                  <span className="px-2 py-1 text-xs bg-cyan-100 text-cyan-700 rounded-full">{item.type}</span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>床位: {item.beds}张</span>
                  <span>评分: {item.rating}分</span>
                </div>
              </div>
            ))}
          </div>
        );
      case 'payment':
        return (
          <div className="bg-white rounded-lg border border-gray-200">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">发放月份</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">金额</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                </tr>
              </thead>
              <tbody>
                {mockData.payment.map((item) => (
                  <tr key={item.id} className="border-t border-gray-100">
                    <td className="px-4 py-3 text-sm text-gray-800">{item.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.month}</td>
                    <td className="px-4 py-3 text-sm text-cyan-600 font-medium">¥{item.amount}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">{item.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'query':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <input
                type="text"
                placeholder="输入身份证号或评估编号"
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
              <button className="px-6 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">查询</button>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg text-center text-gray-500">
              <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>请输入查询条件进行搜索</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
        <span>待遇保障司</span>
        <span>/</span>
        <span className="text-gray-800">长期护理保险</span>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'text-cyan-600 border-b-2 border-cyan-600'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="min-h-[400px]"
      >
        {renderContent()}
      </motion.div>
    </div>
  );
}
