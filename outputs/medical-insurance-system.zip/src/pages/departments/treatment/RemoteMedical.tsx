import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Globe, Search, FileText, TrendingUp, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const tabs = [
  { id: 'apply', label: '异地备案申请', icon: FileText },
  { id: 'query', label: '备案查询', icon: Search },
  { id: 'settlement', label: '结算管理', icon: Globe },
  { id: 'referral', label: '转诊管理', icon: Clock },
  { id: 'stats', label: '异地统计', icon: TrendingUp }
];

const mockData = {
  apply: [
    { id: 'YD2024001', name: '张三', type: '长期异地', status: '待审核', date: '2024-01-15' },
    { id: 'YD2024002', name: '李四', type: '临时外出', status: '已通过', date: '2024-01-14' }
  ],
  query: [
    { id: 'YD2024002', name: '李四', type: '临时外出', status: '有效', expire: '2024-12-31' },
    { id: 'YD2023999', name: '王五', type: '长期异地', status: '已过期', expire: '2023-12-31' }
  ],
  settlement: [
    { id: 'JS2024001', hospital: '北京协和医院', amount: 12500, status: '已结算', date: '2024-01-10' },
    { id: 'JS2024002', hospital: '上海瑞金医院', amount: 8600, status: '待结算', date: '2024-01-12' }
  ],
  referral: [
    { id: 'ZZ2024001', patient: '赵六', from: '县医院', to: '省人民医院', status: '已转诊', date: '2024-01-13' }
  ],
  stats: { total: 3256, month: 156, amount: 4856 }
};

export default function RemoteMedical() {
  const [activeTab, setActiveTab] = useState('apply');

  const renderContent = () => {
    switch (activeTab) {
      case 'apply':
        return (
          <div className="space-y-4">
            <div className="flex gap-4 mb-4">
              <input type="text" placeholder="搜索姓名/身份证号" className="flex-1 px-4 py-2 border rounded-lg" />
              <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg">查询</button>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg">新增备案</button>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr><th className="p-3 text-left">备案编号</th><th className="p-3">姓名</th><th className="p-3">类型</th><th className="p-3">状态</th><th className="p-3">申请日期</th><th className="p-3">操作</th></tr>
              </thead>
              <tbody>
                {mockData.apply.map(item => (
                  <tr key={item.id} className="border-b">
                    <td className="p-3">{item.id}</td>
                    <td className="p-3 text-center">{item.name}</td>
                    <td className="p-3 text-center">{item.type}</td>
                    <td className="p-3 text-center"><span className={`px-2 py-1 rounded text-xs ${item.status === '已通过' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span></td>
                    <td className="p-3 text-center">{item.date}</td>
                    <td className="p-3 text-center"><button className="text-cyan-600">审核</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'query':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">有效备案</p><p className="text-2xl font-bold text-green-600">2,856</p></div>
              <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">即将过期</p><p className="text-2xl font-bold text-yellow-600">128</p></div>
              <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">已过期</p><p className="text-2xl font-bold text-gray-600">272</p></div>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr><th className="p-3 text-left">备案编号</th><th className="p-3">姓名</th><th className="p-3">类型</th><th className="p-3">状态</th><th className="p-3">有效期至</th></tr>
              </thead>
              <tbody>
                {mockData.query.map(item => (
                  <tr key={item.id} className="border-b">
                    <td className="p-3">{item.id}</td>
                    <td className="p-3 text-center">{item.name}</td>
                    <td className="p-3 text-center">{item.type}</td>
                    <td className="p-3 text-center"><span className={`px-2 py-1 rounded text-xs ${item.status === '有效' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></td>
                    <td className="p-3 text-center">{item.expire}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'settlement':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-4 gap-4 mb-4">
              <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">本月结算</p><p className="text-2xl font-bold text-cyan-600">¥485.6万</p></div>
              <div className="bg-white p-4 rounded-lg border"><p className="text-gray-500">待结算</p><p className="text-2xl font-bold text-orange-600">¥86.4万</p></div>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr><th className="p-3 text-left">结算单号</th><th className="p-3">就医医院</th><th className="p-3">金额</th><th className="p-3">状态</th><th className="p-3">日期</th></tr>
              </thead>
              <tbody>
                {mockData.settlement.map(item => (
                  <tr key={item.id} className="border-b">
                    <td className="p-3">{item.id}</td>
                    <td className="p-3 text-center">{item.hospital}</td>
                    <td className="p-3 text-center">¥{item.amount}</td>
                    <td className="p-3 text-center"><span className={`px-2 py-1 rounded text-xs ${item.status === '已结算' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>{item.status}</span></td>
                    <td className="p-3 text-center">{item.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'referral':
        return (
          <div className="space-y-4">
            <div className="flex gap-4 mb-4">
              <button className="px-4 py-2 bg-cyan-600 text-white rounded-lg">新增转诊</button>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr><th className="p-3 text-left">转诊编号</th><th className="p-3">患者</th><th className="p-3">转出医院</th><th className="p-3">转入医院</th><th className="p-3">状态</th><th className="p-3">日期</th></tr>
              </thead>
              <tbody>
                {mockData.referral.map(item => (
                  <tr key={item.id} className="border-b">
                    <td className="p-3">{item.id}</td>
                    <td className="p-3 text-center">{item.patient}</td>
                    <td className="p-3 text-center">{item.from}</td>
                    <td className="p-3 text-center">{item.to}</td>
                    <td className="p-3 text-center"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">{item.status}</span></td>
                    <td className="p-3 text-center">{item.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      case 'stats':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-6 rounded-lg border"><p className="text-gray-500">累计备案人数</p><p className="text-3xl font-bold text-cyan-600">{mockData.stats.total}</p><p className="text-sm text-green-500">+{mockData.stats.month} 本月新增</p></div>
              <div className="bg-white p-6 rounded-lg border"><p className="text-gray-500">本月结算金额</p><p className="text-3xl font-bold text-green-600">{mockData.stats.amount}万</p></div>
              <div className="bg-white p-6 rounded-lg border"><p className="text-gray-500">结算率</p><p className="text-3xl font-bold text-blue-600">98.5%</p></div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">异地就医</h1>
          <p className="text-gray-500 mt-1">异地备案、结算管理、转诊管理</p>
        </div>
      </div>

      <div className="flex gap-2 border-b">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl p-6 shadow-sm border">
        {renderContent()}
      </motion.div>
    </div>
  );
}
