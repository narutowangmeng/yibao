import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, CreditCard, FileText, HeartPulse, Globe, Shield,
  ChevronRight, TrendingUp, Activity, CheckCircle, AlertCircle, ArrowLeft
} from 'lucide-react';
import EnrollmentManagement from './treatment/EnrollmentManagement';
import PaymentManagement from './treatment/PaymentManagement';
import BenefitPolicy from './treatment/BenefitPolicy';
import InsuranceDirectory from './treatment/InsuranceDirectory';
import LongTermCare from './treatment/LongTermCare';
import RemoteMedical from './treatment/RemoteMedical';
import InsuranceTypeManagement from './treatment/InsuranceTypeManagement';

const modules = [
  {
    id: 'enrollment',
    name: '参保管理',
    icon: Users,
    description: '参保登记、信息变更、关系转移接续',
    stats: { total: 1256, today: 45, pending: 12 },
    features: ['个人参保登记', '单位参保登记', '信息变更', '关系转移', '参保查询']
  },
  {
    id: 'insurance-type',
    name: '险种管理',
    icon: Shield,
    description: '医保险种配置、缴费标准、待遇参数管理',
    stats: { total: 4, active: 3, inactive: 1 },
    features: ['险种配置', '缴费标准', '待遇参数', '险种启用/停用', '险种查询']
  },
  {
    id: 'payment',
    name: '缴费管理',
    icon: CreditCard,
    description: '筹资政策、缴费核定、催缴管理',
    stats: { total: 856, today: 128, pending: 23 },
    features: ['缴费核定', '催缴管理', '缴费查询', '欠费处理', '缴费统计']
  },
  {
    id: 'benefit',
    name: '待遇政策',
    icon: Shield,
    description: '医保待遇标准制定、待遇调整',
    stats: { total: 45, today: 2, pending: 3 },
    features: ['待遇标准', '政策制定', '待遇调整', '政策解读', '待遇测算']
  },
  {
    id: 'longterm',
    name: '长期护理保险',
    icon: HeartPulse,
    description: '失能评估、护理服务管理',
    stats: { total: 456, today: 18, pending: 9 },
    features: ['失能评估', '护理服务', '机构管理', '待遇支付', '评估查询']
  },
  {
    id: 'remote',
    name: '异地就医',
    icon: Globe,
    description: '异地备案、结算管理',
    stats: { total: 3256, today: 156, pending: 45 },
    features: ['异地备案', '备案查询', '结算管理', '转诊管理', '异地统计']
  }
];

const stats = [
  { label: '参保人数', value: '12.5亿', change: '+2.3%', trend: 'up' },
  { label: '缴费收入', value: '8,256亿', change: '+8.5%', trend: 'up' },
  { label: '待遇支出', value: '6,842亿', change: '+12.1%', trend: 'up' },
  { label: '政策文件', value: '156份', change: '+15份', trend: 'up' }
];

export default function TreatmentDepartment() {
  const [activeModule, setActiveModule] = useState<string | null>(null);

  const renderModuleContent = () => {
    switch (activeModule) {
      case 'enrollment':
        return <EnrollmentManagement />;
      case 'insurance-type':
        return <InsuranceTypeManagement />;
      case 'payment':
        return <PaymentManagement />;
      case 'benefit':
        return <BenefitPolicy />;
      case 'longterm':
        return <LongTermCare />;
      case 'remote':
        return <RemoteMedical />;
      default:
        return null;
    }
  };

  if (activeModule) {
    const moduleName = modules.find(m => m.id === activeModule)?.name || '';
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveModule(null)}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            返回
          </button>
          <span className="text-gray-400">/</span>
          <span className="text-gray-800 font-medium">{moduleName}</span>
        </div>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeModule}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            {renderModuleContent()}
          </motion.div>
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">待遇保障司</h1>
          <p className="text-gray-500 mt-1">负责医疗保障筹资和待遇政策制定、医保目录管理、长期护理保险等工作</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full">二级部门</span>
          <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full">45人</span>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-5 shadow-sm border border-gray-100"
          >
            <p className="text-sm text-gray-500">{stat.label}</p>
            <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
            <div className="flex items-center gap-1 mt-2">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-sm text-green-500">{stat.change}</span>
              <span className="text-sm text-gray-400">较上月</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-4">
        {modules.map((module, index) => {
          const Icon = module.icon;
          return (
            <motion.div
              key={module.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setActiveModule(module.id)}
            >
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-xl bg-cyan-50 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-cyan-600" />
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
              <h3 className="font-semibold text-gray-800 mt-4">{module.name}</h3>
              <p className="text-sm text-gray-500 mt-1">{module.description}</p>
              
              <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100">
                {module.id === 'insurance-type' ? (
                  <>
                    <div>
                      <p className="text-xs text-gray-400">险种总数</p>
                      <p className="text-lg font-semibold text-gray-800">{module.stats.total}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">启用</p>
                      <p className="text-lg font-semibold text-green-600">{module.stats.active}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">停用</p>
                      <p className="text-lg font-semibold text-gray-500">{module.stats.inactive}</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <p className="text-xs text-gray-400">累计</p>
                      <p className="text-lg font-semibold text-gray-800">{module.stats.total}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">今日</p>
                      <p className="text-lg font-semibold text-cyan-600">{module.stats.today}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">待处理</p>
                      <p className="text-lg font-semibold text-orange-500">{module.stats.pending}</p>
                    </div>
                  </>
                )}
              </div>

              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-4 pt-4 border-t border-gray-100"
              >
                <p className="text-sm font-medium text-gray-700 mb-2">功能列表</p>
                <div className="space-y-2">
                  {module.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-cyan-500" />
                      {feature}
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-center">
                  <span className="text-sm text-cyan-600 font-medium flex items-center gap-1">
                    点击进入 <ChevronRight className="w-4 h-4" />
                  </span>
                </div>
              </motion.div>
            </motion.div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-600" />
          近期动态
        </h3>
        <div className="space-y-3">
          {[
            { time: '10:30', title: '完成2024年度医保目录调整方案', type: '政策' },
            { time: '09:15', title: '新增15种药品纳入医保支付范围', type: '目录' },
            { time: '昨天', title: '发布长期护理保险失能评估标准', type: '长护险' },
            { time: '昨天', title: '异地就医直接结算覆盖范围扩大', type: '异地' }
          ].map((item, idx) => (
            <div key={idx} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-500 w-12">{item.time}</span>
              <span className="px-2 py-1 bg-cyan-100 text-cyan-700 text-xs rounded">{item.type}</span>
              <span className="text-sm text-gray-800">{item.title}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
