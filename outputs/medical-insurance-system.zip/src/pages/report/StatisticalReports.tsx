import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, Download, FileText, TrendingUp, PieChart, Calendar, Users, Building2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell } from 'recharts';

const reportTypes = [
  { id: 'enrollment', name: '参保统计报表', icon: Users },
  { id: 'reimbursement', name: '报销统计报表', icon: FileText },
  { id: 'fund', name: '基金收支报表', icon: TrendingUp },
  { id: 'institution', name: '机构结算报表', icon: Building2 },
];

const monthlyData = [
  { month: '1月', enrollment: 12500, reimbursement: 8600 },
  { month: '2月', enrollment: 13200, reimbursement: 9200 },
  { month: '3月', enrollment: 14100, reimbursement: 9800 },
  { month: '4月', enrollment: 13800, reimbursement: 10100 },
  { month: '5月', enrollment: 14500, reimbursement: 10500 },
  { month: '6月', enrollment: 15200, reimbursement: 11200 },
];

const pieData = [
  { name: '职工医保', value: 45, color: '#0891B2' },
  { name: '居民医保', value: 35, color: '#10B981' },
  { name: '新农合', value: 20, color: '#F59E0B' },
];

export default function StatisticalReports() {
  const [activeReport, setActiveReport] = useState('enrollment');
  const [dateRange, setDateRange] = useState('month');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">统计报表中心</h2>
        <div className="flex gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg text-sm"
          >
            <option value="week">本周</option>
            <option value="month">本月</option>
            <option value="quarter">本季度</option>
            <option value="year">本年度</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#0891B2] text-white rounded-lg hover:bg-[#0e7490]">
            <Download className="w-4 h-4" />
            导出报表
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {reportTypes.map((type) => {
          const Icon = type.icon;
          return (
            <motion.button
              key={type.id}
              whileHover={{ scale: 1.02 }}
              onClick={() => setActiveReport(type.id)}
              className={`p-4 rounded-xl border-2 transition-all ${
                activeReport === type.id
                  ? 'border-[#0891B2] bg-[#0891B2]/5'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <Icon className={`w-8 h-8 mb-2 ${activeReport === type.id ? 'text-[#0891B2]' : 'text-gray-500'}`} />
              <p className="font-medium text-gray-800">{type.name}</p>
            </motion.button>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#0891B2]" />
            业务趋势分析
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="enrollment" fill="#0891B2" name="参保人数" />
              <Bar dataKey="reimbursement" fill="#10B981" name="报销人次" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-[#0891B2]" />
            参保类型分布
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <RePieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RePieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 mt-4">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-gray-600">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-800">报表列表</h3>
        </div>
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报表名称</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报表类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">生成时间</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {[
              { name: '2024年6月参保统计月报', type: '参保统计', time: '2024-06-30', status: '已生成' },
              { name: '2024年Q2基金收支报表', type: '基金收支', time: '2024-06-30', status: '已生成' },
              { name: '医疗机构结算汇总表', type: '机构结算', time: '2024-06-29', status: '已生成' },
            ].map((report, idx) => (
              <tr key={idx} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-800">{report.name}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{report.type}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{report.time}</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">{report.status}</span>
                </td>
                <td className="px-4 py-3">
                  <button className="text-[#0891B2] hover:underline text-sm">下载</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
