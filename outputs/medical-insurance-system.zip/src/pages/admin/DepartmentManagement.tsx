import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Building2,
  Users,
  Shield,
  Plus,
  Search,
  Edit2,
  Trash2,
  ChevronRight,
  ChevronDown,
  UserPlus
} from 'lucide-react';

interface Department {
  id: string;
  name: string;
  code: string;
  level: number;
  parentId?: string;
  manager: string;
  memberCount: number;
  permissions: string[];
  children?: Department[];
}

const departmentData: Department[] = [
  {
    id: '1',
    name: '国家医保局',
    code: 'NHSA',
    level: 1,
    manager: '张局长',
    memberCount: 127,
    permissions: ['全部权限'],
    children: [
      {
        id: '1-1',
        name: '待遇保障司',
        code: 'DYBZS',
        level: 2,
        parentId: '1',
        manager: '王司长',
        memberCount: 45,
        permissions: ['参保管理', '缴费管理', '待遇政策', '医保目录', '长期护理保险', '异地就医']
      },
      {
        id: '1-2',
        name: '基金监管司',
        code: 'JJJGS',
        level: 2,
        parentId: '1',
        manager: '赵司长',
        memberCount: 38,
        permissions: ['基金监管', '飞行检查', '智能监管', '违规查处', '信用管理', '举报投诉']
      },
      {
        id: '1-3',
        name: '医药服务管理司',
        code: 'YYFWGLS',
        level: 2,
        parentId: '1',
        manager: '刘司长',
        memberCount: 44,
        permissions: ['医疗机构管理', '药品管理', '医疗服务价格', '招标采购', '支付方式改革', '医疗服务行为监管']
      }
    ]
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 }
};

export default function DepartmentManagement() {
  const [expandedDepts, setExpandedDepts] = useState<Set<string>>(new Set(['1']));
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<Department | null>(null);

  const toggleExpand = (id: string) => {
    const newSet = new Set(expandedDepts);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedDepts(newSet);
  };

  const renderDepartmentTree = (depts: Department[], level = 0) => {
    return depts.map((dept) => (
      <div key={dept.id}>
        <motion.div
          variants={itemVariants}
          className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${
            selectedDept?.id === dept.id
              ? 'bg-cyan-50 border border-cyan-200'
              : 'hover:bg-gray-50 border border-transparent'
          }`}
          style={{ paddingLeft: `${level * 24 + 12}px` }}
          onClick={() => setSelectedDept(dept)}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleExpand(dept.id);
            }}
            className="p-1 rounded hover:bg-gray-200 mr-2"
          >
            {dept.children ? (
              expandedDepts.has(dept.id) ? (
                <ChevronDown className="w-4 h-4 text-gray-500" />
              ) : (
                <ChevronRight className="w-4 h-4 text-gray-500" />
              )
            ) : (
              <span className="w-4" />
            )}
          </button>
          <Building2 className="w-5 h-5 text-cyan-600 mr-3" />
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-medium text-gray-800">{dept.name}</span>
              <span className="text-xs text-gray-500">({dept.code})</span>
            </div>
            <div className="text-xs text-gray-500 mt-0.5">
              {dept.manager} · {dept.memberCount}人
            </div>
          </div>
        </motion.div>
        {dept.children && expandedDepts.has(dept.id) && (
          <div>{renderDepartmentTree(dept.children, level + 1)}</div>
        )}
      </div>
    ));
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">部门管理</h1>
          <p className="text-gray-500 mt-1">国家医保局三大核心业务司：待遇保障司、基金监管司、医药服务管理司</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors">
            <Plus className="w-4 h-4" />
            新增部门
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <motion.div variants={itemVariants} className="col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="搜索部门..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
            <div className="p-2 max-h-[600px] overflow-y-auto">
              {renderDepartmentTree(departmentData)}
            </div>
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className="col-span-2">
          {selectedDept ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-gray-800">{selectedDept.name}</h2>
                    <p className="text-gray-500 mt-1">部门编码: {selectedDept.code}</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-6">
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Users className="w-4 h-4" />
                      <span className="text-sm">人员数量</span>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">{selectedDept.memberCount}</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Building2 className="w-4 h-4" />
                      <span className="text-sm">部门层级</span>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">{selectedDept.level}级</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <Shield className="w-4 h-4" />
                      <span className="text-sm">权限数量</span>
                    </div>
                    <p className="text-2xl font-bold text-gray-800">{selectedDept.permissions.length}</p>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-800 mb-3">部门职能模块</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {selectedDept.permissions.map((perm, idx) => (
                      <div
                        key={idx}
                        className="px-4 py-3 bg-cyan-50 text-cyan-800 rounded-lg text-sm border border-cyan-100"
                      >
                        <div className="font-medium">{perm}</div>
                        <div className="text-xs text-cyan-600 mt-1">
                          {perm === '参保管理' && '参保登记、信息变更、关系转移接续'}
                          {perm === '缴费管理' && '筹资政策、缴费核定、催缴管理'}
                          {perm === '待遇政策' && '医保待遇标准制定、待遇调整'}
                          {perm === '医保目录' && '药品目录、诊疗项目目录、医用耗材目录管理'}
                          {perm === '长期护理保险' && '失能评估、护理服务管理'}
                          {perm === '异地就医' && '异地备案、结算管理'}
                          {perm === '基金监管' && '基金收支监控、风险预警'}
                          {perm === '飞行检查' && '现场检查、专项检查'}
                          {perm === '智能监管' && '大数据监控、规则库管理'}
                          {perm === '违规查处' && '欺诈骗保查处、违规处理'}
                          {perm === '信用管理' && '定点机构信用评价、黑名单管理'}
                          {perm === '举报投诉' && '举报受理、奖励发放'}
                          {perm === '医疗机构管理' && '定点机构准入、协议管理、退出管理'}
                          {perm === '药品管理' && '药品目录调整、集采管理、价格监测'}
                          {perm === '医疗服务价格' && '价格项目制定、价格调整'}
                          {perm === '招标采购' && '药品耗材招标、采购监管'}
                          {perm === '支付方式改革' && 'DRG/DIP付费、按病种付费'}
                          {perm === '医疗服务行为监管' && '诊疗规范、合理用药'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-800">部门人员</h3>
                    <button className="flex items-center gap-1 text-sm text-cyan-600 hover:text-cyan-700">
                      <UserPlus className="w-4 h-4" />
                      分配人员
                    </button>
                  </div>
                  <div className="border border-gray-200 rounded-lg divide-y divide-gray-200">
                    {[
                      { name: selectedDept.manager, role: '部门负责人', status: '在职' },
                      { name: '张专员', role: '业务专员', status: '在职' },
                      { name: '李专员', role: '业务专员', status: '在职' }
                    ].map((person, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center">
                            <span className="text-sm font-medium text-cyan-700">
                              {person.name[0]}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{person.name}</p>
                            <p className="text-xs text-gray-500">{person.role}</p>
                          </div>
                        </div>
                        <span className="px-2 py-1 bg-green-50 text-green-700 rounded text-xs">
                          {person.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
              <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">请选择左侧部门查看详情</p>
            </div>
          )}
        </motion.div>
      </div>
    </motion.div>
  );
}
