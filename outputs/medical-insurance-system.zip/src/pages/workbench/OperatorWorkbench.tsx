import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Users, CreditCard, FileText, Search, Plus, CheckCircle,
  Clock, TrendingUp, Building2, User, ChevronRight, Filter,
  Download, Eye, Edit2, Upload, QrCode, History, X, ChevronLeft,
  ChevronDown, MoreHorizontal, Printer, RotateCcw, Shield
} from 'lucide-react';
import ChangeModule from './modules/ChangeModule';
import TransferModule from './modules/TransferModule';
import QuerySystem from './QuerySystem';

const tabs = [
  { id: 'enrollment', label: '参保登记', icon: Users },
  { id: 'payment', label: '缴费核定', icon: CreditCard },
  { id: 'change', label: '信息变更', icon: Edit2 },
  { id: 'transfer', label: '关系转移', icon: ChevronRight },
  { id: 'query', label: '业务查询', icon: Search }
];

const mockEnrollmentData = [
  { id: '1', name: '张三', idCard: '110101199001011234', type: '城乡居民', status: '正常', joinDate: '2024-01-15', phone: '13800138001', address: '北京市朝阳区', workUnit: '自由职业' },
  { id: '2', name: '李四', idCard: '110101198505056789', type: '灵活就业', status: '正常', joinDate: '2024-01-14', phone: '13900139002', address: '北京市海淀区', workUnit: '个体经营' },
  { id: '3', name: '王五', idCard: '110101199212123456', type: '城镇职工', status: '审核中', joinDate: '2024-01-13', phone: '13700137003', address: '北京市东城区', workUnit: '科技有限公司' },
];

const mockHistoryData = [
  { id: 'H001', action: '参保登记', date: '2024-01-15', operator: '经办人员A', status: '成功' },
  { id: 'H002', action: '信息变更', date: '2023-12-20', operator: '经办人员B', status: '成功' },
  { id: 'H003', action: '关系转移', date: '2023-06-10', operator: '经办人员A', status: '成功' },
];

export default function OperatorWorkbench() {
  const [activeTab, setActiveTab] = useState('enrollment');
  const [showModal, setShowModal] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formStep, setFormStep] = useState(1);
  const [isReadingCard, setIsReadingCard] = useState(false);
  const [formData, setFormData] = useState({
    name: '', idCard: '', type: '城乡居民', phone: '', address: '', workUnit: ''
  });

  const stats = { today: 45, pending: 12, completed: 128, total: 1256 };

  const handleReadCard = () => {
    setIsReadingCard(true);
    setTimeout(() => {
      setFormData({ ...formData, name: '张三', idCard: '110101199001011234' });
      setIsReadingCard(false);
    }, 1500);
  };

  const handleSubmit = () => {
    setFormStep(3);
    setTimeout(() => {
      setShowModal(false);
      setFormStep(1);
      setFormData({ name: '', idCard: '', type: '城乡居民', phone: '', address: '', workUnit: '' });
    }, 2000);
  };

  const renderEnrollmentContent = () => (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索姓名或身份证号" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
          <Plus className="w-4 h-4" />新增登记
        </button>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Upload className="w-4 h-4" />批量导入
        </button>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Download className="w-4 h-4" />导出
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">身份证号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">联系电话</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">工作单位</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockEnrollmentData.map((item) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{item.name}</td>
                <td className="px-4 py-3 text-sm text-gray-600 font-mono">{item.idCard}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.phone}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.workUnit}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${item.status === '正常' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button onClick={() => { setSelectedRecord(item); setShowDetail(true); }} className="p-1 text-gray-400 hover:text-cyan-600"><Eye className="w-4 h-4" /></button>
                    <button onClick={() => { setSelectedRecord(item); setShowHistory(true); }} className="p-1 text-gray-400 hover:text-cyan-600"><History className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderPaymentContent = () => (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索姓名或身份证号" className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg"><Plus className="w-4 h-4" />新增核定</button>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <p className="text-sm text-gray-500">待核定人数</p>
          <p className="text-2xl font-bold text-orange-600">156</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <p className="text-sm text-gray-500">本月已核定</p>
          <p className="text-2xl font-bold text-green-600">2,340</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-gray-200">
          <p className="text-sm text-gray-500">核定金额</p>
          <p className="text-2xl font-bold text-cyan-600">¥468万</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">经办人员工作台</h2>
          <p className="text-sm text-gray-500 mt-1">办理参保登记、缴费核定、信息变更等日常业务</p>
        </div>
        <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm">经办人员</span>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">今日办理</p>
          <p className="text-2xl font-bold text-cyan-600">{stats.today}</p>
          <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><TrendingUp className="w-3 h-3" />较昨日 +8</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">待处理</p>
          <p className="text-2xl font-bold text-orange-600">{stats.pending}</p>
          <p className="text-xs text-orange-500 mt-1">需尽快处理</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">本月完成</p>
          <p className="text-2xl font-bold text-green-600">{stats.completed}</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">经办总数</p>
          <p className="text-2xl font-bold text-gray-800">{stats.total}</p>
        </motion.div>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'}`}>
            <tab.icon className="w-4 h-4" />{tab.label}
          </button>
        ))}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {activeTab === 'enrollment' && renderEnrollmentContent()}
        {activeTab === 'payment' && renderPaymentContent()}
        {activeTab === 'change' && <ChangeModule />}
        {activeTab === 'transfer' && <TransferModule />}
        {activeTab === 'query' && <QuerySystem />}
      </motion.div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-2xl rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">新增参保登记</h3>
              <button onClick={() => setShowModal(false)} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex gap-2 mb-6">
              {[1, 2, 3].map((step) => (
                <div key={step} className={`flex-1 h-2 rounded ${formStep >= step ? 'bg-cyan-600' : 'bg-gray-200'}`} />
              ))}
            </div>
            {formStep === 1 && (
              <div className="space-y-4">
                <div className="flex justify-center mb-6">
                  <button onClick={handleReadCard} disabled={isReadingCard} className="flex items-center gap-2 px-6 py-3 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 disabled:opacity-50">
                    <QrCode className="w-5 h-5" />
                    {isReadingCard ? '读取中...' : '读取身份证'}
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="mb-1 block text-sm font-medium text-gray-700">姓名 *</label><input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2" placeholder="请输入姓名" /></div>
                  <div><label className="mb-1 block text-sm font-medium text-gray-700">身份证号 *</label><input type="text" value={formData.idCard} onChange={(e) => setFormData({ ...formData, idCard: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2" placeholder="请输入身份证号" /></div>
                </div>
                <div><label className="mb-1 block text-sm font-medium text-gray-700">参保类型 *</label><select value={formData.type} onChange={(e) => setFormData({ ...formData, type: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2"><option>城乡居民基本医疗保险</option><option>灵活就业人员医保</option><option>城镇职工基本医疗保险</option></select></div>
                <div><label className="mb-1 block text-sm font-medium text-gray-700">联系电话</label><input type="text" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2" placeholder="请输入联系电话" /></div>
                <div><label className="mb-1 block text-sm font-medium text-gray-700">户籍地址</label><input type="text" value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2" placeholder="请输入户籍地址" /></div>
                <div><label className="mb-1 block text-sm font-medium text-gray-700">工作单位</label><input type="text" value={formData.workUnit} onChange={(e) => setFormData({ ...formData, workUnit: e.target.value })} className="w-full rounded-lg border border-gray-200 px-3 py-2" placeholder="请输入工作单位" /></div>
                <div className="flex justify-end gap-3 mt-6"><button onClick={() => setShowModal(false)} className="rounded-lg px-4 py-2 text-gray-600 hover:bg-gray-100">取消</button><button onClick={() => setFormStep(2)} className="rounded-lg bg-cyan-600 px-4 py-2 text-white hover:bg-cyan-700">下一步</button></div>
              </div>
            )}
            {formStep === 2 && (
              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-800 mb-3">参保资格审核</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /><span className="text-sm text-gray-600">身份证信息验证通过</span></div>
                    <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /><span className="text-sm text-gray-600">未重复参保</span></div>
                    <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /><span className="text-sm text-gray-600">符合参保条件</span></div>
                  </div>
                </div>
                <div className="bg-cyan-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-800 mb-2">登记信息确认</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm"><span className="text-gray-500">姓名:</span><span>{formData.name}</span><span className="text-gray-500">身份证号:</span><span>{formData.idCard}</span><span className="text-gray-500">参保类型:</span><span>{formData.type}</span><span className="text-gray-500">联系电话:</span><span>{formData.phone}</span></div>
                </div>
                <div className="flex justify-end gap-3 mt-6"><button onClick={() => setFormStep(1)} className="rounded-lg px-4 py-2 text-gray-600 hover:bg-gray-100">上一步</button><button onClick={handleSubmit} className="rounded-lg bg-cyan-600 px-4 py-2 text-white hover:bg-cyan-700">提交登记</button></div>
              </div>
            )}
            {formStep === 3 && (
              <div className="text-center py-8">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-800 mb-2">登记成功</h4>
                <p className="text-sm text-gray-500">参保登记已提交，等待审核</p>
              </div>
            )}
          </motion.div>
        </div>
      )}

      {showHistory && selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">历史记录 - {selectedRecord.name}</h3>
              <button onClick={() => setShowHistory(false)} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              {mockHistoryData.map((item) => (
                <div key={item.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <History className="w-4 h-4 text-gray-400" />
                  <div className="flex-1"><p className="text-sm font-medium text-gray-800">{item.action}</p><p className="text-xs text-gray-500">{item.date} · {item.operator}</p></div>
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">{item.status}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}

      {showDetail && selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">参保详情</h3>
              <button onClick={() => setShowDetail(false)} className="p-1 hover:bg-gray-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm"><span className="text-gray-500">姓名:</span><span className="text-gray-800">{selectedRecord.name}</span><span className="text-gray-500">身份证号:</span><span className="text-gray-800 font-mono">{selectedRecord.idCard}</span><span className="text-gray-500">参保类型:</span><span className="text-gray-800">{selectedRecord.type}</span><span className="text-gray-500">联系电话:</span><span className="text-gray-800">{selectedRecord.phone}</span><span className="text-gray-500">户籍地址:</span><span className="text-gray-800">{selectedRecord.address}</span><span className="text-gray-500">工作单位:</span><span className="text-gray-800">{selectedRecord.workUnit}</span><span className="text-gray-500">参保日期:</span><span className="text-gray-800">{selectedRecord.joinDate}</span><span className="text-gray-500">状态:</span><span className={`${selectedRecord.status === '正常' ? 'text-green-600' : 'text-yellow-600'}`}>{selectedRecord.status}</span></div>
            </div>
            <div className="flex justify-end gap-3 mt-6"><button onClick={() => setShowDetail(false)} className="rounded-lg px-4 py-2 text-gray-600 hover:bg-gray-100">关闭</button><button className="rounded-lg bg-cyan-600 px-4 py-2 text-white hover:bg-cyan-700">打印凭证</button></div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
