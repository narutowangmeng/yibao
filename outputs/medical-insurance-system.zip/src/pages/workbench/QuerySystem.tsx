import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, FileText, Download, Calendar, User, CreditCard, HeartPulse, ChevronRight, Filter, X } from 'lucide-react';

const queryTypes = [
  { id: 'comprehensive', label: '综合查询', icon: Search },
  { id: 'records', label: '办理记录', icon: FileText },
  { id: 'status', label: '参保状态', icon: HeartPulse },
  { id: 'payment', label: '缴费记录', icon: CreditCard },
  { id: 'reimbursement', label: '报销记录', icon: FileText },
];

const mockResults = [
  { id: 'P001', name: '张三', idCard: '110101199001011234', type: '城乡居民', status: '正常', lastPay: '2024-03', amount: '580元' },
  { id: 'P002', name: '李四', idCard: '110101198505056789', type: '灵活就业', status: '正常', lastPay: '2024-03', amount: '1200元' },
];

export default function QuerySystem() {
  const [activeType, setActiveType] = useState('comprehensive');
  const [searchParams, setSearchParams] = useState({ name: '', idCard: '', cardNo: '' });
  const [showResults, setShowResults] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  const handleSearch = () => {
    setShowResults(true);
  };

  const handleExport = () => {
    alert('查询结果导出成功');
  };

  const renderQueryForm = () => {
    switch (activeType) {
      case 'comprehensive':
        return (
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">姓名</label>
              <input type="text" value={searchParams.name} onChange={(e) => setSearchParams({...searchParams, name: e.target.value})} className="w-full px-3 py-2 border border-gray-200 rounded-lg" placeholder="请输入姓名" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">身份证号</label>
              <input type="text" value={searchParams.idCard} onChange={(e) => setSearchParams({...searchParams, idCard: e.target.value})} className="w-full px-3 py-2 border border-gray-200 rounded-lg" placeholder="请输入身份证号" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">参保号</label>
              <input type="text" value={searchParams.cardNo} onChange={(e) => setSearchParams({...searchParams, cardNo: e.target.value})} className="w-full px-3 py-2 border border-gray-200 rounded-lg" placeholder="请输入参保号" />
            </div>
          </div>
        );
      case 'records':
        return (
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">业务类型</label>
              <select className="w-full px-3 py-2 border border-gray-200 rounded-lg">
                <option>全部</option>
                <option>参保登记</option>
                <option>信息变更</option>
                <option>缴费核定</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">开始日期</label>
              <input type="date" className="w-full px-3 py-2 border border-gray-200 rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">结束日期</label>
              <input type="date" className="w-full px-3 py-2 border border-gray-200 rounded-lg" />
            </div>
          </div>
        );
      default:
        return (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">身份证号/参保号</label>
              <input type="text" className="w-full px-3 py-2 border border-gray-200 rounded-lg" placeholder="请输入查询条件" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">查询年度</label>
              <select className="w-full px-3 py-2 border border-gray-200 rounded-lg">
                <option>2024</option>
                <option>2023</option>
                <option>2022</option>
              </select>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 border-b border-gray-200">
        {queryTypes.map((type) => {
          const Icon = type.icon;
          return (
            <button key={type.id} onClick={() => { setActiveType(type.id); setShowResults(false); }} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeType === type.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'}`}>
              <Icon className="w-4 h-4" />{type.label}
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        {renderQueryForm()}
        <div className="flex gap-3 mt-4">
          <button onClick={handleSearch} className="flex items-center gap-2 px-6 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700">
            <Search className="w-4 h-4" />查询
          </button>
          <button onClick={handleExport} className="flex items-center gap-2 px-6 py-2 border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50">
            <Download className="w-4 h-4" />导出结果
          </button>
        </div>
      </div>

      {showResults && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
            <span className="font-medium text-gray-700">查询结果 (共 {mockResults.length} 条)</span>
            <button onClick={() => setShowResults(false)} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">身份证号</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保类型</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">最近缴费</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
              </tr>
            </thead>
            <tbody>
              {mockResults.map((item) => (
                <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-800">{item.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-600 font-mono">{item.idCard}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">{item.status}</span></td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.lastPay}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => setSelectedRecord(item)} className="text-cyan-600 hover:text-cyan-700 text-sm flex items-center gap-1">
                      详情<ChevronRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {selectedRecord && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-2xl bg-white rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">参保人详情</h3>
              <button onClick={() => setSelectedRecord(null)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">姓名:</span> <span className="font-medium">{selectedRecord.name}</span></div>
              <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">身份证号:</span> <span className="font-medium">{selectedRecord.idCard}</span></div>
              <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">参保类型:</span> <span className="font-medium">{selectedRecord.type}</span></div>
              <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">参保状态:</span> <span className="font-medium text-green-600">{selectedRecord.status}</span></div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
