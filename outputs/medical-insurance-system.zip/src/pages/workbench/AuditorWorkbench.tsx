import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText, CheckCircle, XCircle, AlertTriangle, Search,
  Filter, Eye, ChevronRight, Clock, TrendingUp, BarChart3,
  User, Calendar, DollarSign, Stethoscope, Pill, Building2,
  MessageSquare, History, CheckSquare, RotateCcw, Download
} from 'lucide-react';
import AuditInspection from './modules/AuditInspection';
import AuditAbnormalPanel from './components/AuditAbnormalPanel';

const tabs = [
  { id: 'pending', label: '待审核', icon: FileText, count: 23 },
  { id: 'audit', label: '费用审核', icon: CheckCircle },
  { id: 'inspection', label: '稽核检查', icon: AlertTriangle },
  { id: 'abnormal', label: '异常数据', icon: AlertTriangle },
  { id: 'completed', label: '已审核', icon: History }
];

const mockPendingList = [
  { id: 'R202401001', name: '张三', idCard: '110101199001011234', amount: 12580.5, type: '住院报销', hospital: '北京协和医院', date: '2024-01-15', status: '待审核', days: 2 },
  { id: 'R202401002', name: '李四', idCard: '110101198505056789', amount: 3680.0, type: '门诊报销', hospital: '北京同仁医院', date: '2024-01-14', status: '待审核', days: 1 },
  { id: 'R202401003', name: '王五', idCard: '110101199212123456', amount: 25600.0, type: '住院报销', hospital: '北京301医院', date: '2024-01-13', status: '待审核', days: 3 },
];

const mockAuditRules = [
  { id: 1, name: '医保目录校验', status: 'passed', message: '所有药品和诊疗项目均在医保目录内' },
  { id: 2, name: '费用限额检查', status: 'passed', message: '费用未超出年度限额' },
  { id: 3, name: '重复收费检测', status: 'warning', message: '发现疑似重复检查项目' },
  { id: 4, name: '合理用药审查', status: 'passed', message: '用药符合临床规范' },
];

const mockFeeDetails = [
  { item: '床位费', spec: '普通病房', qty: 10, unit: '天', price: 50, amount: 500, category: '诊疗费' },
  { item: '头孢呋辛', spec: '0.75g', qty: 20, unit: '支', price: 25.5, amount: 510, category: '药品费' },
  { item: '血常规', spec: '全套', qty: 2, unit: '次', price: 80, amount: 160, category: '检查费' },
  { item: 'CT检查', spec: '胸部', qty: 1, unit: '次', price: 450, amount: 450, category: '检查费' },
];

export default function AuditorWorkbench() {
  const [activeTab, setActiveTab] = useState('pending');
  const [selectedRecord, setSelectedRecord] = useState<string | null>(null);
  const [auditOpinion, setAuditOpinion] = useState('');
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [auditResult, setAuditResult] = useState<'pass' | 'reject' | null>(null);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  const stats = {
    today: 18,
    pending: 23,
    passed: 156,
    rejected: 12
  };

  const handleBatchAudit = () => {
    alert(`批量审核 ${selectedItems.length} 条记录`);
    setSelectedItems([]);
  };

  const handleAuditSubmit = () => {
    setShowAuditModal(false);
    setSelectedRecord(null);
    setAuditOpinion('');
    setAuditResult(null);
  };

  const toggleSelection = (id: string) => {
    setSelectedItems(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const renderPendingList = () => (
    <div className="space-y-4">
      <div className="flex gap-4 items-center">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索姓名、身份证号或单据号" className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Filter className="w-4 h-4" />筛选
        </button>
        {selectedItems.length > 0 && (
          <button onClick={handleBatchAudit} className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg">
            <CheckSquare className="w-4 h-4" />批量审核({selectedItems.length})
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl border border-gray-200">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3"><input type="checkbox" onChange={(e) => setSelectedItems(e.target.checked ? mockPendingList.map(i => i.id) : [])} checked={selectedItems.length === mockPendingList.length} /></th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">单据号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报销类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">医疗机构</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">提交时间</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockPendingList.map((item) => (
              <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                <td className="px-4 py-3"><input type="checkbox" checked={selectedItems.includes(item.id)} onChange={() => toggleSelection(item.id)} /></td>
                <td className="px-4 py-3 text-sm font-mono text-gray-600">{item.id}</td>
                <td className="px-4 py-3 text-sm font-medium text-gray-800">{item.name}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{item.hospital}</td>
                <td className="px-4 py-3 text-sm font-medium text-cyan-600">¥{item.amount.toFixed(2)}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{item.date}</td>
                <td className="px-4 py-3">
                  <button onClick={() => { setSelectedRecord(item.id); setShowAuditModal(true); }} className="flex items-center gap-1 px-3 py-1 bg-cyan-50 text-cyan-600 rounded text-sm hover:bg-cyan-100">
                    <Eye className="w-3 h-3" />审核
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderAuditDetail = () => (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-cyan-600" />智能审核规则校验
        </h3>
        <div className="space-y-3">
          {mockAuditRules.map((rule) => (
            <div key={rule.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              {rule.status === 'passed' ? <CheckCircle className="w-5 h-5 text-green-500" /> :
               rule.status === 'warning' ? <AlertTriangle className="w-5 h-5 text-orange-500" /> :
               <XCircle className="w-5 h-5 text-red-500" />}
              <div className="flex-1">
                <p className="font-medium text-gray-800">{rule.name}</p>
                <p className="text-sm text-gray-500">{rule.message}</p>
              </div>
              <span className={`px-2 py-1 text-xs rounded ${rule.status === 'passed' ? 'bg-green-100 text-green-700' : rule.status === 'warning' ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'}`}>
                {rule.status === 'passed' ? '通过' : rule.status === 'warning' ? '警告' : '不通过'}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-cyan-600" />费用明细
        </h3>
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">项目</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">规格</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">数量</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">单价</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">金额</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">类别</th>
            </tr>
          </thead>
          <tbody>
            {mockFeeDetails.map((item, idx) => (
              <tr key={idx} className="border-t border-gray-100">
                <td className="px-4 py-2 text-sm text-gray-800">{item.item}</td>
                <td className="px-4 py-2 text-sm text-gray-500">{item.spec}</td>
                <td className="px-4 py-2 text-sm text-gray-600">{item.qty}{item.unit}</td>
                <td className="px-4 py-2 text-sm text-gray-600">¥{item.price}</td>
                <td className="px-4 py-2 text-sm font-medium text-gray-800">¥{item.amount}</td>
                <td className="px-4 py-2"><span className="px-2 py-1 text-xs bg-gray-100 rounded">{item.category}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">审核人员工作台</h2>
          <p className="text-sm text-gray-500 mt-1">费用报销审核、稽核检查、异常数据核查</p>
        </div>
        <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm">审核人员</span>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">今日审核</p>
          <p className="text-2xl font-bold text-cyan-600">{stats.today}</p>
          <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><TrendingUp className="w-3 h-3" />较昨日 +5</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">待审核</p>
          <p className="text-2xl font-bold text-orange-600">{stats.pending}</p>
          <p className="text-xs text-orange-500 mt-1">需尽快处理</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">审核通过</p>
          <p className="text-2xl font-bold text-green-600">{stats.passed}</p>
          <p className="text-xs text-gray-400 mt-1">本月累计</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">审核驳回</p>
          <p className="text-2xl font-bold text-red-600">{stats.rejected}</p>
          <p className="text-xs text-gray-400 mt-1">本月累计</p>
        </motion.div>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600 hover:text-gray-800'}`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
              {tab.count && <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded-full">{tab.count}</span>}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {activeTab === 'pending' && renderPendingList()}
        {activeTab === 'audit' && renderAuditDetail()}
        {activeTab === 'inspection' && <AuditInspection />}
        {activeTab === 'abnormal' && <AuditAbnormalPanel />}
        {activeTab === 'completed' && <div className="bg-gray-50 rounded-xl p-8 text-center text-gray-500"><History className="w-12 h-12 mx-auto mb-3 text-gray-300" /><p>审核历史查询</p></div>}
      </motion.div>

      <AnimatePresence>
        {showAuditModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} className="w-full max-w-2xl rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto">
              <h3 className="mb-4 text-lg font-semibold text-gray-800 flex items-center gap-2">
                <FileText className="w-5 h-5 text-cyan-600" />费用报销审核
              </h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
                  <div><span className="text-sm text-gray-500">单据号:</span><p className="font-medium">R202401001</p></div>
                  <div><span className="text-sm text-gray-500">申请人:</span><p className="font-medium">张三</p></div>
                  <div><span className="text-sm text-gray-500">身份证号:</span><p className="font-mono">110101199001011234</p></div>
                  <div><span className="text-sm text-gray-500">报销金额:</span><p className="font-medium text-cyan-600">¥12,580.50</p></div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-800 mb-2">智能审核结果</h4>
                  <div className="space-y-2">
                    {mockAuditRules.slice(0, 3).map((rule) => (
                      <div key={rule.id} className="flex items-center gap-2 text-sm">
                        {rule.status === 'passed' ? <CheckCircle className="w-4 h-4 text-green-500" /> : <AlertTriangle className="w-4 h-4 text-orange-500" />}
                        <span className="text-gray-600">{rule.name}: {rule.message}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-800 mb-2">审核结论</h4>
                  <div className="flex gap-4">
                    <button onClick={() => setAuditResult('pass')} className={`flex-1 p-4 rounded-lg border-2 text-center transition-colors ${auditResult === 'pass' ? 'border-green-500 bg-green-50' : 'border-gray-200 hover:border-green-300'}`}>
                      <CheckCircle className={`w-8 h-8 mx-auto mb-2 ${auditResult === 'pass' ? 'text-green-600' : 'text-gray-400'}`} />
                      <p className="font-medium">审核通过</p>
                    </button>
                    <button onClick={() => setAuditResult('reject')} className={`flex-1 p-4 rounded-lg border-2 text-center transition-colors ${auditResult === 'reject' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-red-300'}`}>
                      <XCircle className={`w-8 h-8 mx-auto mb-2 ${auditResult === 'reject' ? 'text-red-600' : 'text-gray-400'}`} />
                      <p className="font-medium">审核驳回</p>
                    </button>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-800 mb-2">审核意见</h4>
                  <textarea value={auditOpinion} onChange={(e) => setAuditOpinion(e.target.value)} placeholder="请输入审核意见..." className="w-full h-24 p-3 border border-gray-200 rounded-lg resize-none" />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button onClick={() => setShowAuditModal(false)} className="rounded-lg px-4 py-2 text-gray-600 hover:bg-gray-100">取消</button>
                <button onClick={handleAuditSubmit} disabled={!auditResult} className="rounded-lg bg-cyan-600 px-4 py-2 text-white hover:bg-cyan-700 disabled:opacity-50">提交审核</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
