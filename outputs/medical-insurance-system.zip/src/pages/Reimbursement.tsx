import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, CheckCircle, XCircle, Clock, FileText, Eye, 
  Filter, Download, TrendingUp, TrendingDown, AlertCircle,
  ChevronDown, Calendar, Building2, User, CreditCard,
  ArrowRight, Printer, RotateCcw
} from 'lucide-react';

// 报销类型
interface ReimbursementItem {
  id: string;
  applicant: string;
  idCard: string;
  phone: string;
  type: 'outpatient' | 'inpatient' | 'pharmacy' | 'chronic' | 'emergency';
  amount: number;
  reimbursedAmount: number;
  selfPayAmount: number;
  status: 'pending' | 'reviewing' | 'approved' | 'rejected' | 'paid';
  applyDate: string;
  hospital: string;
  department: string;
  diagnosis: string;
  medicalRecordNo: string;
  invoiceNo: string;
  attachments: number;
  reviewer?: string;
  reviewDate?: string;
  rejectReason?: string;
  paymentDate?: string;
  paymentMethod?: string;
}

// 报销类型标签
const typeLabels: Record<string, { label: string; color: string; icon: any }> = {
  outpatient: { label: '门诊', color: 'bg-blue-100 text-blue-700', icon: Building2 },
  inpatient: { label: '住院', color: 'bg-violet-100 text-violet-700', icon: Building2 },
  pharmacy: { label: '药店购药', color: 'bg-green-100 text-green-700', icon: CreditCard },
  chronic: { label: '慢特病', color: 'bg-amber-100 text-amber-700', icon: AlertCircle },
  emergency: { label: '急诊', color: 'bg-red-100 text-red-700', icon: AlertCircle },
};

// 状态标签
const statusLabels: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: '待提交', color: 'bg-gray-100 text-gray-700', icon: Clock },
  reviewing: { label: '审核中', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
  approved: { label: '已通过', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  rejected: { label: '已拒绝', color: 'bg-red-100 text-red-700', icon: XCircle },
  paid: { label: '已支付', color: 'bg-blue-100 text-blue-700', icon: CheckCircle },
};

// 模拟数据
const mockData: ReimbursementItem[] = [
  { 
    id: 'RB202412001', 
    applicant: '张三', 
    idCard: '110101199001011234',
    phone: '13800138001',
    type: 'outpatient', 
    amount: 580, 
    reimbursedAmount: 420,
    selfPayAmount: 160,
    status: 'paid', 
    applyDate: '2024-12-20', 
    hospital: '北京协和医院',
    department: '内科',
    diagnosis: '上呼吸道感染',
    medicalRecordNo: '20241220001',
    invoiceNo: 'INV20241220001',
    attachments: 3,
    reviewer: '李审核员',
    reviewDate: '2024-12-21',
    paymentDate: '2024-12-22',
    paymentMethod: '银行卡转账'
  },
  { 
    id: 'RB202412002', 
    applicant: '李四', 
    idCard: '110101198505056789',
    phone: '13800138002',
    type: 'inpatient', 
    amount: 12500, 
    reimbursedAmount: 9800,
    selfPayAmount: 2700,
    status: 'reviewing', 
    applyDate: '2024-12-21', 
    hospital: '北京大学人民医院',
    department: '心内科',
    diagnosis: '冠心病',
    medicalRecordNo: '20241221002',
    invoiceNo: 'INV20241221002',
    attachments: 5
  },
  { 
    id: 'RB202412003', 
    applicant: '王五', 
    idCard: '110101199212123456',
    phone: '13800138003',
    type: 'pharmacy', 
    amount: 320, 
    reimbursedAmount: 0,
    selfPayAmount: 320,
    status: 'rejected', 
    applyDate: '2024-12-19', 
    hospital: '北京朝阳医院',
    department: '药房',
    diagnosis: '购药',
    medicalRecordNo: '-',
    invoiceNo: 'INV20241219003',
    attachments: 2,
    reviewer: '李审核员',
    reviewDate: '2024-12-20',
    rejectReason: '非医保目录内药品，不符合报销条件'
  },
  { 
    id: 'RB202412004', 
    applicant: '赵六', 
    idCard: '110101199508081111',
    phone: '13900139001',
    type: 'chronic', 
    amount: 850, 
    reimbursedAmount: 680,
    selfPayAmount: 170,
    status: 'approved', 
    applyDate: '2024-12-18', 
    hospital: '北京天坛医院',
    department: '内分泌科',
    diagnosis: '2型糖尿病',
    medicalRecordNo: '20241218004',
    invoiceNo: 'INV20241218004',
    attachments: 4,
    reviewer: '王审核员',
    reviewDate: '2024-12-19'
  },
  { 
    id: 'RB202412005', 
    applicant: '钱七', 
    idCard: '110101199303032222',
    phone: '13900139002',
    type: 'emergency', 
    amount: 2100, 
    reimbursedAmount: 1680,
    selfPayAmount: 420,
    status: 'pending', 
    applyDate: '2024-12-22', 
    hospital: '北京急救中心',
    department: '急诊科',
    diagnosis: '急性阑尾炎',
    medicalRecordNo: '20241222005',
    invoiceNo: 'INV20241222005',
    attachments: 3
  },
];

export default function Reimbursement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [dateRange, setDateRange] = useState<string>('all');
  const [showDetail, setShowDetail] = useState<ReimbursementItem | null>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewingItem, setReviewingItem] = useState<ReimbursementItem | null>(null);

  // 筛选数据
  const filteredData = mockData.filter(item => {
    const matchSearch = item.applicant.includes(searchTerm) || 
                       item.idCard.includes(searchTerm) ||
                       item.id.includes(searchTerm);
    const matchStatus = filterStatus === 'all' || item.status === filterStatus;
    const matchType = filterType === 'all' || item.type === filterType;
    return matchSearch && matchStatus && matchType;
  });

  // 统计数据
  const stats = {
    total: mockData.length,
    totalAmount: mockData.reduce((sum, item) => sum + item.amount, 0),
    totalReimbursed: mockData.reduce((sum, item) => sum + item.reimbursedAmount, 0),
    pending: mockData.filter(i => i.status === 'pending' || i.status === 'reviewing').length,
    approved: mockData.filter(i => i.status === 'approved' || i.status === 'paid').length,
    rejected: mockData.filter(i => i.status === 'rejected').length,
  };

  // 报销比例
  const reimbursementRate = stats.totalAmount > 0 
    ? Math.round((stats.totalReimbursed / stats.totalAmount) * 100) 
    : 0;

  const handleReview = (item: ReimbursementItem) => {
    setReviewingItem(item);
    setShowReviewModal(true);
  };

  const handleViewDetail = (item: ReimbursementItem) => {
    setShowDetail(item);
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[#134E4A]">报销管理</h2>
          <p className="text-sm text-gray-500 mt-1">处理医疗费用报销申请与审核</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Printer size={16} />
            打印报表
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Download size={16} />
            导出数据
          </button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">报销总额</p>
          <p className="text-2xl font-bold text-[#0891B2]">¥{stats.totalAmount.toLocaleString()}</p>
          <p className="text-xs text-gray-400 mt-1">本月累计</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">已报销金额</p>
          <p className="text-2xl font-bold text-green-600">¥{stats.totalReimbursed.toLocaleString()}</p>
          <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
            <TrendingUp size={12} />
            报销比例 {reimbursementRate}%
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">待审核</p>
          <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
          <p className="text-xs text-gray-400 mt-1">需要处理</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">已通过</p>
          <p className="text-2xl font-bold text-blue-600">{stats.approved}</p>
          <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
            <TrendingDown size={12} />
            拒绝 {stats.rejected} 笔
          </p>
        </motion.div>
      </div>

      {/* 搜索和筛选 */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="搜索申请人、身份证号或单号"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-gray-200 py-2 pl-10 pr-4 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white min-w-[120px]"
          >
            <option value="all">全部类型</option>
            <option value="outpatient">门诊</option>
            <option value="inpatient">住院</option>
            <option value="pharmacy">药店购药</option>
            <option value="chronic">慢特病</option>
            <option value="emergency">急诊</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
        <div className="relative">
          <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white min-w-[120px]"
          >
            <option value="all">全部状态</option>
            <option value="pending">待提交</option>
            <option value="reviewing">审核中</option>
            <option value="approved">已通过</option>
            <option value="rejected">已拒绝</option>
            <option value="paid">已支付</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white min-w-[120px]"
          >
            <option value="all">全部时间</option>
            <option value="today">今天</option>
            <option value="week">本周</option>
            <option value="month">本月</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
      </div>

      {/* 数据表格 */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="border-b border-gray-200 bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报销单号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">申请人</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">医疗机构</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">总金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">报销金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">申请日期</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => {
              const TypeIcon = typeLabels[item.type].icon;
              const StatusIcon = statusLabels[item.status].icon;
              return (
                <motion.tr
                  key={item.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <span className="text-sm font-mono text-gray-600">{item.id}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{item.applicant}</p>
                      <p className="text-xs text-gray-500">{item.idCard}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${typeLabels[item.type].color}`}>
                      <TypeIcon size={12} />
                      {typeLabels[item.type].label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.hospital}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">¥{item.amount.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${
                      item.reimbursedAmount > 0 ? 'text-green-600' : 'text-gray-400'
                    }`}>
                      {item.reimbursedAmount > 0 ? `¥${item.reimbursedAmount.toLocaleString()}` : '-'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{item.applyDate}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${statusLabels[item.status].color}`}>
                      <StatusIcon size={12} />
                      {statusLabels[item.status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => handleViewDetail(item)}
                        className="p-1.5 rounded-md text-gray-500 hover:text-[#0891B2] hover:bg-[#0891B2]/10 transition-colors"
                        title="查看详情"
                      >
                        <Eye size={16} />
                      </button>
                      {(item.status === 'pending' || item.status === 'reviewing') && (
                        <button 
                          onClick={() => handleReview(item)}
                          className="p-1.5 rounded-md text-gray-500 hover:text-green-600 hover:bg-green-50 transition-colors"
                          title="审核"
                        >
                          <CheckCircle size={16} />
                        </button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
        {filteredData.length === 0 && (
          <div className="py-12 text-center text-gray-400">
            <FileText size={48} className="mx-auto mb-3 opacity-30" />
            <p>暂无报销记录</p>
          </div>
        )}
      </div>

      {/* 详情弹窗 */}
      <AnimatePresence>
        {showDetail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-3xl rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              {/* 弹窗头部 */}
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-semibold text-[#134E4A]">报销详情</h3>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${statusLabels[showDetail.status].color}`}>
                      {statusLabels[showDetail.status].label}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500">单号: {showDetail.id}</p>
                </div>
                <button
                  onClick={() => setShowDetail(null)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="sr-only">关闭</span>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* 申请人信息 */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                    <User size={16} className="text-[#0891B2]" />
                    申请人信息
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">姓名</span>
                      <span className="font-medium">{showDetail.applicant}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">身份证号</span>
                      <span className="font-mono">{showDetail.idCard}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">联系电话</span>
                      <span>{showDetail.phone}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                    <Building2 size={16} className="text-[#0891B2]" />
                    就诊信息
                  </h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">医疗机构</span>
                      <span>{showDetail.hospital}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">就诊科室</span>
                      <span>{showDetail.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">诊断结果</span>
                      <span>{showDetail.diagnosis}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 费用明细 */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                  <CreditCard size={16} className="text-[#0891B2]" />
                  费用明细
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-white rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">总费用</p>
                    <p className="text-xl font-bold text-gray-900">¥{showDetail.amount.toLocaleString()}</p>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">报销金额</p>
                    <p className="text-xl font-bold text-green-600">¥{showDetail.reimbursedAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center p-3 bg-white rounded-lg">
                    <p className="text-sm text-gray-500 mb-1">自付金额</p>
                    <p className="text-xl font-bold text-orange-600">¥{showDetail.selfPayAmount.toLocaleString()}</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-200 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">病历号</span>
                    <span className="font-mono">{showDetail.medicalRecordNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">发票号</span>
                    <span className="font-mono">{showDetail.invoiceNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">附件数量</span>
                    <span>{showDetail.attachments} 个文件</span>
                  </div>
                </div>
              </div>

              {/* 审核流程 */}
              <div className="mb-6">
                <h4 className="font-medium text-gray-900 mb-3">审核流程</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                      <CheckCircle size={16} className="text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">提交申请</p>
                      <p className="text-xs text-gray-500">{showDetail.applyDate}</p>
                    </div>
                  </div>
                  {showDetail.reviewDate && (
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        showDetail.status === 'rejected' ? 'bg-red-100' : 'bg-green-100'
                      }`}>
                        {showDetail.status === 'rejected' ? (
                          <XCircle size={16} className="text-red-600" />
                        ) : (
                          <CheckCircle size={16} className="text-green-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">
                          {showDetail.status === 'rejected' ? '审核拒绝' : '审核通过'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {showDetail.reviewDate} · 审核人: {showDetail.reviewer}
                        </p>
                        {showDetail.rejectReason && (
                          <p className="text-xs text-red-500 mt-1">原因: {showDetail.rejectReason}</p>
                        )}
                      </div>
                    </div>
                  )}
                  {showDetail.paymentDate && (
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <CheckCircle size={16} className="text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">支付完成</p>
                        <p className="text-xs text-gray-500">
                          {showDetail.paymentDate} · {showDetail.paymentMethod}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* 操作按钮 */}
              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setShowDetail(null)}
                  className="rounded-lg px-4 py-2 text-gray-600 transition hover:bg-gray-100"
                >
                  关闭
                </button>
                {(showDetail.status === 'pending' || showDetail.status === 'reviewing') && (
                  <button
                    onClick={() => {
                      setShowDetail(null);
                      handleReview(showDetail);
                    }}
                    className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                  >
                    去审核
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 审核弹窗 */}
      <AnimatePresence>
        {showReviewModal && reviewingItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl"
            >
              <h3 className="text-lg font-semibold text-[#134E4A] mb-4">报销审核</h3>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">申请人</span>
                  <span className="font-medium">{reviewingItem.applicant}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">总费用</span>
                  <span className="font-bold text-lg">¥{reviewingItem.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">医疗机构</span>
                  <span>{reviewingItem.hospital}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">审核结果</label>
                  <div className="grid grid-cols-2 gap-3">
                    <label className="cursor-pointer">
                      <input type="radio" name="reviewResult" value="approve" className="sr-only" defaultChecked />
                      <div className="border-2 border-green-200 bg-green-50 rounded-lg p-3 text-center hover:border-green-400 transition-colors">
                        <CheckCircle className="mx-auto mb-1 text-green-600" size={24} />
                        <p className="font-medium text-green-700">通过</p>
                      </div>
                    </label>
                    <label className="cursor-pointer">
                      <input type="radio" name="reviewResult" value="reject" className="sr-only" />
                      <div className="border-2 border-red-200 bg-red-50 rounded-lg p-3 text-center hover:border-red-400 transition-colors">
                        <XCircle className="mx-auto mb-1 text-red-600" size={24} />
                        <p className="font-medium text-red-700">拒绝</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">报销金额</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">¥</span>
                    <input
                      type="number"
                      defaultValue={Math.round(reviewingItem.amount * 0.8)}
                      className="w-full rounded-lg border border-gray-200 pl-8 pr-4 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">建议报销比例: 80%</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">审核备注</label>
                  <textarea
                    rows={3}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20 resize-none"
                    placeholder="请输入审核意见..."
                  />
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  onClick={() => setShowReviewModal(false)}
                  className="rounded-lg px-4 py-2 text-gray-600 transition hover:bg-gray-100"
                >
                  取消
                </button>
                <button
                  onClick={() => setShowReviewModal(false)}
                  className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                >
                  确认审核
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
