import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Building,
  FileText,
  Calendar,
  Download,
  Search,
  Filter,
  ChevronDown,
  AlertCircle
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const fundStats = [
  { label: '基金总收入', value: '¥8,256.8万', change: '+12.5%', trend: 'up' },
  { label: '基金总支出', value: '¥6,842.3万', change: '+8.3%', trend: 'up' },
  { label: '基金结余', value: '¥1,414.5万', change: '+28.6%', trend: 'up' },
  { label: '账户数量', value: '156个', change: '+5个', trend: 'up' },
];

const monthlyData = [
  { month: '1月', income: 680, expense: 520 },
  { month: '2月', income: 720, expense: 580 },
  { month: '3月', income: 780, expense: 620 },
  { month: '4月', income: 750, expense: 600 },
  { month: '5月', income: 820, expense: 650 },
  { month: '6月', income: 850, expense: 680 },
];

const accountData = [
  { name: '统筹基金', value: 45, color: '#0891B2' },
  { name: '个人账户', value: 35, color: '#10B981' },
  { name: '大病保险', value: 15, color: '#F59E0B' },
  { name: '其他账户', value: 5, color: '#6B7280' },
];

const accounts = [
  { id: 1, name: '城镇职工统筹基金', type: '统筹基金', balance: '¥4,256.8万', status: '正常' },
  { id: 2, name: '城乡居民统筹基金', type: '统筹基金', balance: '¥2,156.3万', status: '正常' },
  { id: 3, name: '个人账户基金', type: '个人账户', balance: '¥1,842.5万', status: '正常' },
  { id: 4, name: '大病保险基金', type: '大病保险', balance: '¥685.2万', status: '正常' },
];

const reports = [
  { id: 1, name: '2024年6月基金收支月报', type: '月报', date: '2024-07-05', status: '已生成' },
  { id: 2, name: '2024年第二季度基金分析报告', type: '季报', date: '2024-07-01', status: '已生成' },
  { id: 3, name: '2024年上半年基金预算执行情况', type: '半年报', date: '2024-06-30', status: '已生成' },
];

export default function FundManagement() {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'overview', label: '基金概览' },
    { id: 'accounts', label: '账户管理' },
    { id: 'reports', label: '财务报表' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">基金管理</h1>
          <p className="text-sm text-gray-500 mt-1">医保基金收支管理与财务分析</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
            <Calendar className="w-4 h-4" />
            选择期间
            <ChevronDown className="w-4 h-4" />
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#0891B2] text-white rounded-lg text-sm font-medium hover:bg-[#0e7490]">
            <Download className="w-4 h-4" />
            导出报表
          </button>
        </div>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-[#0891B2] text-[#0891B2]'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="grid grid-cols-4 gap-4">
            {fundStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white p-6 rounded-xl border border-gray-200"
              >
                <p className="text-sm text-gray-500">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                <div className="flex items-center gap-1 mt-2">
                  {stat.trend === 'up' ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}
                  <span className={`text-sm ${stat.trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
                    {stat.change}
                  </span>
                  <span className="text-sm text-gray-400">较上月</span>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">收支趋势</h3>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} />
                  <YAxis stroke="#9ca3af" fontSize={12} />
                  <Tooltip />
                  <Area type="monotone" dataKey="income" stackId="1" stroke="#0891B2" fill="#0891B2" fillOpacity={0.6} name="收入" />
                  <Area type="monotone" dataKey="expense" stackId="1" stroke="#EF4444" fill="#EF4444" fillOpacity={0.6} name="支出" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">账户分布</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={accountData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {accountData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex justify-center gap-4 mt-4">
                {accountData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-sm text-gray-600">{item.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {activeTab === 'accounts' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl border border-gray-200"
        >
          <div className="p-4 border-b border-gray-200 flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="搜索账户名称..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#0891B2]"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">
              <Filter className="w-4 h-4" />
              筛选
            </button>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">账户名称</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">账户类型</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">账户余额</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">状态</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {accounts.map((account) => (
                <tr key={account.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <Wallet className="w-5 h-5 text-[#0891B2]" />
                      <span className="text-sm font-medium text-gray-900">{account.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{account.type}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{account.balance}</td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                      {account.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button className="text-sm text-[#0891B2] hover:underline">查看明细</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}

      {activeTab === 'reports' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl border border-gray-200"
        >
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">财务报表</h3>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#0891B2] text-white rounded-lg text-sm font-medium hover:bg-[#0e7490]">
              <FileText className="w-4 h-4" />
              生成报表
            </button>
          </div>
          <div className="divide-y divide-gray-200">
            {reports.map((report) => (
              <div key={report.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                <div className="flex items-center gap-4">
                  <FileText className="w-10 h-10 text-[#0891B2]" />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{report.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{report.type} · {report.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                    {report.status}
                  </span>
                  <button className="p-2 text-gray-400 hover:text-[#0891B2]">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
