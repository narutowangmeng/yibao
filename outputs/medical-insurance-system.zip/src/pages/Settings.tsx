import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Shield, Database, FileText, Bell, User, Save } from 'lucide-react';

const tabs = [
  { id: 'basic', label: '基础设置', icon: Settings },
  { id: 'permission', label: '用户权限', icon: Shield },
  { id: 'backup', label: '数据备份', icon: Database },
  { id: 'log', label: '日志管理', icon: FileText },
];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('basic');
  const [systemName, setSystemName] = useState('国家医保管理平台');
  const [notifyEnabled, setNotifyEnabled] = useState(true);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-[#134E4A] mb-6">系统设置</h2>

      <div className="flex gap-6">
        <div className="w-48 flex-shrink-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#0891B2] text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon size={18} />
                <span className="text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex-1 bg-white rounded-xl p-6 shadow-sm border border-gray-100"
        >
          {activeTab === 'basic' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-[#134E4A]">基础设置</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">系统名称</label>
                <input
                  type="text"
                  value={systemName}
                  onChange={(e) => setSystemName(e.target.value)}
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-[#0891B2] focus:outline-none"
                />
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <Bell size={18} className="text-[#0891B2]" />
                  <span className="text-sm text-gray-700">消息通知</span>
                </div>
                <button
                  onClick={() => setNotifyEnabled(!notifyEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    notifyEnabled ? 'bg-[#0891B2]' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${
                      notifyEnabled ? 'translate-x-6' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>
              <button className="flex items-center gap-2 bg-[#0891B2] text-white px-4 py-2 rounded-lg hover:bg-[#0891B2]/90 transition">
                <Save size={16} />
                保存设置
              </button>
            </div>
          )}

          {activeTab === 'permission' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-[#134E4A]">用户权限管理</h3>
              {['超级管理员', '数据管理员', '审核员', '普通用户'].map((role, idx) => (
                <div key={role} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <User size={18} className="text-gray-400" />
                    <span className="text-sm text-gray-700">{role}</span>
                  </div>
                  <button className="text-sm text-[#0891B2] hover:underline">配置权限</button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-[#134E4A]">数据备份</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-2">上次备份: 2024-06-30 02:00</p>
                <p className="text-sm text-gray-600">备份大小: 2.3 GB</p>
              </div>
              <button className="bg-[#0891B2] text-white px-4 py-2 rounded-lg hover:bg-[#0891B2]/90 transition">
                立即备份
              </button>
            </div>
          )}

          {activeTab === 'log' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-[#134E4A]">操作日志</h3>
              <div className="space-y-2">
                {[
                  { time: '2024-06-30 10:23', action: '用户登录', user: 'admin' },
                  { time: '2024-06-30 09:15', action: '数据导出', user: 'admin' },
                  { time: '2024-06-29 18:30', action: '权限修改', user: 'admin' },
                ].map((log, idx) => (
                  <div key={idx} className="flex items-center justify-between py-2 border-b border-gray-100 text-sm">
                    <span className="text-gray-500">{log.time}</span>
                    <span className="text-gray-700">{log.action}</span>
                    <span className="text-[#0891B2]">{log.user}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
