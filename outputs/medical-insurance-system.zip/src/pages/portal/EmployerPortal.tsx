import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Building2, Users, CreditCard, FileText, Search, Plus,
  Download, Upload, AlertCircle, CheckCircle, Clock, TrendingUp
} from 'lucide-react';

const tabs = [
  { id: 'company', label: '单位管理', icon: Building2 },
  { id: 'employees', label: '员工管理', icon: Users },
  { id: 'payment', label: '缴费申报', icon: CreditCard },
  { id: 'query', label: '医保查询', icon: FileText }
];

const mockEmployees = [
  { id: '1', name: '张三', idCard: '110101199001011234', status: '正常', joinDate: '2023-01-15' },
  { id: '2', name: '李四', idCard: '110101198505056789', status: '正常', joinDate: '2023-03-20' }
];

const mockPayments = [
  { month: '2024-01', amount: 12580, status: '已缴费', date: '2024-01-15' },
  { month: '2023-12', amount: 12400, status: '已缴费', date: '2023-12-15' }
];

export default function EmployerPortal() {
  const [activeTab, setActiveTab] = useState('company');
  const [showAddModal, setShowAddModal] = useState(false);

  const stats = { totalEmployees: 156, activeEmployees: 148, monthlyPayment: 12580, arrears: 0 };

  const renderContent = () => {
    switch (activeTab) {
      case 'company':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 border border-gray-200">
              <h3 className="font-semibold text-gray-800 mb-4">单位基本信息</h3>
              <div className="grid grid-cols-2 gap-4">
                <div><span className="text-gray-500">单位名称:</span> <span className="font-medium">科技有限公司</span></div>
                <div><span className="text-gray-500">统一社会信用代码:</span> <span className="font-medium">91110108XXXXXXXX</span></div>
                <div><span className="text-gray-500">参保状态:</span> <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-sm">正常参保</span></div>
                <div><span className="text-gray-500">参保人数:</span> <span className="font-medium">{stats.totalEmployees}人</span></div>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-xl border"><p className="text-sm text-gray-500">员工总数</p><p className="text-2xl font-bold text-cyan-600">{stats.totalEmployees}</p></div>
              <div className="bg-white p-4 rounded-xl border"><p className="text-sm text-gray-500">正常参保</p><p className="text-2xl font-bold text-green-600">{stats.activeEmployees}</p></div>
              <div className="bg-white p-4 rounded-xl border"><p className="text-sm text-gray-500">月缴费额</p><p className="text-2xl font-bold text-cyan-600">¥{stats.monthlyPayment}</p></div>
              <div className="bg-white p-4 rounded-xl border"><p className="text-sm text-gray-500">欠费金额</p><p className="text-2xl font-bold text-red-600">¥{stats.arrears}</p></div>
            </div>
          </div>
        );
      case 'employees':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1 relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" /><input type="text" placeholder="搜索员工姓名或身份证号" className="w-full pl-10 pr-4 py-2 border rounded-lg" /></div>
              <button onClick={() => setShowAddModal(true)} className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg"><Plus className="w-4 h-4" />新增员工</button>
              <button className="flex items-center gap-2 px-4 py-2 border rounded-lg"><Upload className="w-4 h-4" />批量导入</button>
            </div>
            <div className="bg-white rounded-xl border overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50"><tr><th className="px-4 py-3 text-left text-sm font-medium">姓名</th><th className="px-4 py-3 text-left text-sm font-medium">身份证号</th><th className="px-4 py-3 text-left text-sm font-medium">状态</th><th className="px-4 py-3 text-left text-sm font-medium">参保日期</th><th className="px-4 py-3 text-left text-sm font-medium">操作</th></tr></thead>
                <tbody>{mockEmployees.map(emp => (<tr key={emp.id} className="border-t"><td className="px-4 py-3 font-medium">{emp.name}</td><td className="px-4 py-3 text-gray-600">{emp.idCard}</td><td className="px-4 py-3"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">{emp.status}</span></td><td className="px-4 py-3 text-gray-600">{emp.joinDate}</td><td className="px-4 py-3"><button className="text-red-600 text-sm">停保</button></td></tr>))}</tbody>
              </table>
            </div>
          </div>
        );
      case 'payment':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <button className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg"><CreditCard className="w-4 h-4" />月度申报</button>
              <button className="flex items-center gap-2 px-4 py-2 border rounded-lg"><Download className="w-4 h-4" />导出明细</button>
            </div>
            <div className="bg-white rounded-xl border overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50"><tr><th className="px-4 py-3 text-left text-sm font-medium">缴费月份</th><th className="px-4 py-3 text-left text-sm font-medium">缴费金额</th><th className="px-4 py-3 text-left text-sm font-medium">状态</th><th className="px-4 py-3 text-left text-sm font-medium">缴费日期</th></tr></thead>
                <tbody>{mockPayments.map((pay, idx) => (<tr key={idx} className="border-t"><td className="px-4 py-3">{pay.month}</td><td className="px-4 py-3 font-medium">¥{pay.amount}</td><td className="px-4 py-3"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">{pay.status}</span></td><td className="px-4 py-3 text-gray-600">{pay.date}</td></tr>))}</tbody>
              </table>
            </div>
          </div>
        );
      default:
        return <div className="bg-gray-50 rounded-xl p-8 text-center text-gray-500">医保查询功能</div>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-bold text-gray-800">参保单位门户</h2><p className="text-sm text-gray-500">单位参保管理、员工增减员、缴费申报</p></div>
        <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm">参保单位</span>
      </div>
      <div className="flex gap-2 border-b">
        {tabs.map(tab => (<button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600'}`}><tab.icon className="w-4 h-4" />{tab.label}</button>))}
      </div>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>{renderContent()}</motion.div>
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="w-full max-w-lg bg-white rounded-xl p-6">
            <h3 className="font-semibold mb-4">新增员工参保</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium mb-1">姓名</label><input type="text" className="w-full border rounded-lg px-3 py-2" /></div>
                <div><label className="block text-sm font-medium mb-1">身份证号</label><input type="text" className="w-full border rounded-lg px-3 py-2" /></div>
              </div>
              <div><label className="block text-sm font-medium mb-1">联系电话</label><input type="text" className="w-full border rounded-lg px-3 py-2" /></div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-gray-600">取消</button>
              <button onClick={() => setShowAddModal(false)} className="px-4 py-2 bg-cyan-600 text-white rounded-lg">提交</button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
