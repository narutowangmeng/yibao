import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  User, CreditCard, FileText, Globe, Clock, CheckCircle,
  AlertCircle, Download, Printer, ChevronRight, Search,
  TrendingUp, Shield, HeartPulse, Eye, Plus
} from 'lucide-react';

const tabs = [
  { id: 'info', label: '参保信息', icon: User },
  { id: 'reimbursement', label: '报销查询', icon: FileText },
  { id: 'payment', label: '缴费记录', icon: CreditCard },
  { id: 'remote', label: '异地就医', icon: Globe }
];

const mockUserInfo = {
  name: '张三',
  idCard: '110101199001011234',
  cardNo: 'BJ2024001234',
  type: '城镇职工基本医疗保险',
  status: '正常参保',
  joinDate: '2020-03-15',
  employer: '北京科技有限公司',
  balance: 2856.50
};

const mockReimbursements = [
  { id: 'R202401001', type: '门诊报销', amount: 580, status: '已到账', date: '2024-01-15', hospital: '北京协和医院' },
  { id: 'R202401002', type: '住院报销', amount: 12580, status: '审核中', date: '2024-01-10', hospital: '北京301医院' }
];

const mockPayments = [
  { year: '2024', month: '01', amount: 580, status: '已缴费', date: '2024-01-05' },
  { year: '2023', month: '12', amount: 580, status: '已缴费', date: '2023-12-05' },
  { year: '2023', month: '11', amount: 580, status: '已缴费', date: '2023-11-05' }
];

const mockRemoteRecords = [
  { id: 'Y202401001', targetCity: '上海市', status: '已备案', startDate: '2024-01-01', endDate: '2024-12-31' }
];

export default function PersonalService() {
  const [activeTab, setActiveTab] = useState('info');
  const [showApplyModal, setShowApplyModal] = useState(false);

  const renderInfo = () => (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-80">医保账户余额</p>
            <p className="text-3xl font-bold">¥{mockUserInfo.balance.toFixed(2)}</p>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
            <CreditCard className="w-6 h-6" />
          </div>
        </div>
        <div className="mt-4 flex gap-4 text-sm">
          <span>参保状态: {mockUserInfo.status}</span>
          <span>参保类型: {mockUserInfo.type}</span>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="font-semibold text-gray-800 mb-4">基本信息</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><span className="text-gray-500">姓名:</span> <span className="font-medium">{mockUserInfo.name}</span></div>
          <div><span className="text-gray-500">身份证号:</span> <span className="font-mono">{mockUserInfo.idCard}</span></div>
          <div><span className="text-gray-500">参保号:</span> <span className="font-mono">{mockUserInfo.cardNo}</span></div>
          <div><span className="text-gray-500">参保日期:</span> {mockUserInfo.joinDate}</div>
          <div><span className="text-gray-500">参保单位:</span> {mockUserInfo.employer}</div>
        </div>
      </div>
    </div>
  );

  const renderReimbursement = () => (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="flex-1 bg-white rounded-xl p-4 border border-gray-200">
          <p className="text-sm text-gray-500">年度累计报销</p>
          <p className="text-2xl font-bold text-cyan-600">¥13,160</p>
        </div>
        <div className="flex-1 bg-white rounded-xl p-4 border border-gray-200">
          <p className="text-sm text-gray-500">报销次数</p>
          <p className="text-2xl font-bold text-green-600">12次</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">单据号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockReimbursements.map((item) => (
              <tr key={item.id} className="border-t border-gray-100">
                <td className="px-4 py-3 text-sm font-mono">{item.id}</td>
                <td className="px-4 py-3 text-sm">{item.type}</td>
                <td className="px-4 py-3 text-sm font-medium text-cyan-600">¥{item.amount}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${item.status === '已到账' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span>
                </td>
                <td className="px-4 py-3">
                  <button className="text-cyan-600 text-sm flex items-center gap-1"><Eye className="w-4 h-4" />查看</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderPayment = () => (
    <div className="space-y-4">
      <div className="flex gap-2">
        <select className="px-4 py-2 border border-gray-200 rounded-lg">
          <option>2024年</option>
          <option>2023年</option>
        </select>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50">
          <Download className="w-4 h-4" />导出记录
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费年月</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费日期</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockPayments.map((item) => (
              <tr key={`${item.year}-${item.month}`} className="border-t border-gray-100">
                <td className="px-4 py-3 text-sm">{item.year}年{item.month}月</td>
                <td className="px-4 py-3 text-sm font-medium">¥{item.amount}</td>
                <td className="px-4 py-3 text-sm">{item.date}</td>
                <td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">{item.status}</span></td>
                <td className="px-4 py-3">
                  <button className="text-cyan-600 text-sm flex items-center gap-1"><Printer className="w-4 h-4" />打印凭证</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderRemote = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold text-gray-800">异地就医备案</h3>
        <button onClick={() => setShowApplyModal(true)} className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg">
          <Plus className="w-4 h-4" />申请备案
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">备案编号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">就医地</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">有效期</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
            </tr>
          </thead>
          <tbody>
            {mockRemoteRecords.map((item) => (
              <tr key={item.id} className="border-t border-gray-100">
                <td className="px-4 py-3 text-sm font-mono">{item.id}</td>
                <td className="px-4 py-3 text-sm">{item.targetCity}</td>
                <td className="px-4 py-3 text-sm">{item.startDate} 至 {item.endDate}</td>
                <td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">{item.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl">
            <h3 className="text-lg font-semibold mb-4">异地就医备案申请</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">就医城市</label>
                <select className="w-full border border-gray-200 rounded-lg px-3 py-2">
                  <option>上海市</option>
                  <option>广州市</option>
                  <option>深圳市</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">开始日期</label>
                  <input type="date" className="w-full border border-gray-200 rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">结束日期</label>
                  <input type="date" className="w-full border border-gray-200 rounded-lg px-3 py-2" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">备案原因</label>
                <textarea className="w-full border border-gray-200 rounded-lg px-3 py-2 h-20" placeholder="请输入备案原因" />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setShowApplyModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">取消</button>
              <button onClick={() => setShowApplyModal(false)} className="px-4 py-2 bg-cyan-600 text-white rounded-lg">提交申请</button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">个人服务大厅</h2>
          <p className="text-sm text-gray-500 mt-1">查询参保信息、报销进度、缴费记录，办理异地就医备案</p>
        </div>
        <span className="px-3 py-1 bg-cyan-100 text-cyan-700 rounded-full text-sm">参保人员</span>
      </div>

      <div className="flex gap-2 border-b border-gray-200">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600'}`}>
              <Icon className="w-4 h-4" />{tab.label}
            </button>
          );
        })}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {activeTab === 'info' && renderInfo()}
        {activeTab === 'reimbursement' && renderReimbursement()}
        {activeTab === 'payment' && renderPayment()}
        {activeTab === 'remote' && renderRemote()}
      </motion.div>
    </div>
  );
}
