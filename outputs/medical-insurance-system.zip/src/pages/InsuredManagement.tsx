import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Plus, Edit2, UserCheck, UserX, Building2, User, 
  ChevronDown, Filter, Download, Eye, History, CreditCard,
  TrendingUp, TrendingDown, AlertCircle
} from 'lucide-react';

// 参保类型定义
interface InsuredPerson {
  id: string;
  name: string;
  idCard: string;
  phone: string;
  category: 'personal' | 'enterprise'; // 个人或企业参保
  type: 'urban_employee' | 'urban_resident' | 'flexible' | 'rural'; // 具体类型
  status: 'active' | 'suspended' | 'terminated';
  joinDate: string;
  lastPayment: string;
  paymentStatus: 'paid' | 'unpaid' | 'overdue';
  balance: number;
  companyName?: string; // 企业名称（职工医保）
  paymentGrade?: string; // 缴费档次
  annualFee?: number; // 年缴费金额
}

// 缴费档次
const paymentGrades = [
  { id: 'grade1', name: '一档', amount: 400, description: '基础保障' },
  { id: 'grade2', name: '二档', amount: 600, description: '标准保障' },
  { id: 'grade3', name: '三档', amount: 900, description: '优质保障' },
];

// 模拟数据
const mockPersonalData: InsuredPerson[] = [
  { 
    id: '1', 
    name: '张三', 
    idCard: '110101199001011234', 
    phone: '13800138001',
    category: 'personal',
    type: 'urban_resident', 
    status: 'active', 
    joinDate: '2020-01-15',
    lastPayment: '2024-12', 
    paymentStatus: 'paid',
    balance: 2580.5,
    paymentGrade: '二档',
    annualFee: 600
  },
  { 
    id: '2', 
    name: '李四', 
    idCard: '110101198505056789', 
    phone: '13800138002',
    category: 'personal',
    type: 'flexible', 
    status: 'active', 
    joinDate: '2019-03-20',
    lastPayment: '2024-12', 
    paymentStatus: 'paid',
    balance: 3200,
    paymentGrade: '一档',
    annualFee: 400
  },
  { 
    id: '3', 
    name: '王五', 
    idCard: '110101199212123456', 
    phone: '13800138003',
    category: 'personal',
    type: 'rural', 
    status: 'suspended', 
    joinDate: '2018-06-10',
    lastPayment: '2024-06', 
    paymentStatus: 'overdue',
    balance: 890.2,
    paymentGrade: '一档',
    annualFee: 400
  },
];

const mockEnterpriseData: InsuredPerson[] = [
  { 
    id: '4', 
    name: '赵六', 
    idCard: '110101199508081111', 
    phone: '13900139001',
    category: 'enterprise',
    type: 'urban_employee', 
    status: 'active', 
    joinDate: '2021-07-01',
    lastPayment: '2024-12', 
    paymentStatus: 'paid',
    balance: 5680.5,
    companyName: '北京科技有限公司',
    annualFee: 3600
  },
  { 
    id: '5', 
    name: '钱七', 
    idCard: '110101199303032222', 
    phone: '13900139002',
    category: 'enterprise',
    type: 'urban_employee', 
    status: 'active', 
    joinDate: '2022-02-15',
    lastPayment: '2024-12', 
    paymentStatus: 'paid',
    balance: 4200,
    companyName: '北京科技有限公司',
    annualFee: 3600
  },
];

const typeLabels: Record<string, string> = {
  urban_employee: '城镇职工',
  urban_resident: '城乡居民',
  flexible: '灵活就业',
  rural: '新农合',
};

const statusLabels: Record<string, { label: string; color: string; icon: any }> = {
  active: { label: '正常', color: 'bg-green-100 text-green-700', icon: UserCheck },
  suspended: { label: '暂停', color: 'bg-yellow-100 text-yellow-700', icon: AlertCircle },
  terminated: { label: '终止', color: 'bg-red-100 text-red-700', icon: UserX },
};

const paymentStatusLabels: Record<string, { label: string; color: string }> = {
  paid: { label: '已缴费', color: 'text-green-600' },
  unpaid: { label: '待缴费', color: 'text-yellow-600' },
  overdue: { label: '已欠费', color: 'text-red-600' },
};

export default function InsuredManagement() {
  const [activeTab, setActiveTab] = useState<'personal' | 'enterprise'>('personal');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingPerson, setEditingPerson] = useState<InsuredPerson | null>(null);
  const [showDetail, setShowDetail] = useState<InsuredPerson | null>(null);

  const currentData = activeTab === 'personal' ? mockPersonalData : mockEnterpriseData;
  
  const filteredData = currentData.filter(p => {
    const matchSearch = p.name.includes(searchTerm) || p.idCard.includes(searchTerm) || 
                       (p.companyName && p.companyName.includes(searchTerm));
    const matchStatus = filterStatus === 'all' || p.status === filterStatus;
    return matchSearch && matchStatus;
  });

  // 统计数据
  const stats = {
    total: currentData.length,
    active: currentData.filter(p => p.status === 'active').length,
    paid: currentData.filter(p => p.paymentStatus === 'paid').length,
    unpaid: currentData.filter(p => p.paymentStatus !== 'paid').length,
    totalBalance: currentData.reduce((sum, p) => sum + p.balance, 0),
  };

  const handleEdit = (person: InsuredPerson) => {
    setEditingPerson(person);
    setShowModal(true);
  };

  const handleAdd = () => {
    setEditingPerson(null);
    setShowModal(true);
  };

  const handleViewDetail = (person: InsuredPerson) => {
    setShowDetail(person);
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[#134E4A]">参保管理</h2>
          <p className="text-sm text-gray-500 mt-1">管理个人和企业参保人员信息</p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-2 rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90 shadow-sm"
        >
          <Plus size={18} />
          新增参保
        </button>
      </div>

      {/* Tab切换 */}
      <div className="flex gap-2 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('personal')}
          className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'personal' 
              ? 'text-[#0891B2]' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <User size={18} />
          个人参保
          {activeTab === 'personal' && (
            <motion.div 
              layoutId="activeTab"
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0891B2]" 
            />
          )}
        </button>
        <button
          onClick={() => setActiveTab('enterprise')}
          className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative ${
            activeTab === 'enterprise' 
              ? 'text-[#0891B2]' 
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Building2 size={18} />
          企业参保
          {activeTab === 'enterprise' && (
            <motion.div 
              layoutId="activeTab"
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0891B2]" 
            />
          )}
        </button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">参保总人数</p>
          <p className="text-2xl font-bold text-[#134E4A]">{stats.total}</p>
          <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
            <TrendingUp size={12} />
            较上月 +12
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">正常参保</p>
          <p className="text-2xl font-bold text-green-600">{stats.active}</p>
          <p className="text-xs text-gray-400 mt-1">占比 {Math.round(stats.active/stats.total*100)}%</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">已缴费</p>
          <p className="text-2xl font-bold text-[#0891B2]">{stats.paid}</p>
          <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
            <TrendingDown size={12} />
            欠费 {stats.unpaid} 人
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">账户总余额</p>
          <p className="text-2xl font-bold text-violet-600">¥{(stats.totalBalance/10000).toFixed(2)}万</p>
          <p className="text-xs text-gray-400 mt-1">个人账户累计</p>
        </motion.div>
      </div>

      {/* 搜索和筛选 */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder={activeTab === 'personal' ? "搜索姓名或身份证号" : "搜索姓名、企业名称"}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-gray-200 py-2 pl-10 pr-4 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white"
          >
            <option value="all">全部状态</option>
            <option value="active">正常</option>
            <option value="suspended">暂停</option>
            <option value="terminated">终止</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
          <Download size={16} />
          导出
        </button>
      </div>

      {/* 数据表格 */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="border-b border-gray-200 bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">姓名</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">身份证号</th>
              {activeTab === 'enterprise' && (
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">所属企业</th>
              )}
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费档次/金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">账户余额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((person, index) => {
              const StatusIcon = statusLabels[person.status].icon;
              return (
                <motion.tr
                  key={person.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#0891B2] to-[#22D3EE] flex items-center justify-center text-white text-xs font-medium">
                        {person.name[0]}
                      </div>
                      <span className="text-sm font-medium text-gray-900">{person.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600 font-mono">{person.idCard}</td>
                  {activeTab === 'enterprise' && (
                    <td className="px-4 py-3 text-sm text-gray-600">{person.companyName}</td>
                  )}
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-600">{typeLabels[person.type]}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-sm text-gray-600">
                      {person.paymentGrade || `¥${person.annualFee}/年`}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${statusLabels[person.status].color}`}>
                      <StatusIcon size={12} />
                      {statusLabels[person.status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-sm font-medium ${paymentStatusLabels[person.paymentStatus].color}`}>
                      {paymentStatusLabels[person.paymentStatus].label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">
                    ¥{person.balance.toLocaleString()}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button 
                        onClick={() => handleViewDetail(person)}
                        className="p-1.5 rounded-md text-gray-500 hover:text-[#0891B2] hover:bg-[#0891B2]/10 transition-colors"
                        title="查看详情"
                      >
                        <Eye size={16} />
                      </button>
                      <button 
                        onClick={() => handleEdit(person)}
                        className="p-1.5 rounded-md text-gray-500 hover:text-[#0891B2] hover:bg-[#0891B2]/10 transition-colors"
                        title="编辑"
                      >
                        <Edit2 size={16} />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
        {filteredData.length === 0 && (
          <div className="py-12 text-center text-gray-400">
            <User size={48} className="mx-auto mb-3 opacity-30" />
            <p>暂无数据</p>
          </div>
        )}
      </div>

      {/* 新增/编辑弹窗 */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <h3 className="mb-4 text-lg font-semibold text-[#134E4A]">
                {editingPerson ? '编辑参保信息' : `新增${activeTab === 'personal' ? '个人' : '企业'}参保`}
              </h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">姓名 *</label>
                    <input
                      type="text"
                      defaultValue={editingPerson?.name || ''}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                      placeholder="请输入姓名"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">身份证号 *</label>
                    <input
                      type="text"
                      defaultValue={editingPerson?.idCard || ''}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                      placeholder="请输入身份证号"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1 block text-sm font-medium text-gray-700">联系电话</label>
                  <input
                    type="text"
                    defaultValue={editingPerson?.phone || ''}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                    placeholder="请输入联系电话"
                  />
                </div>

                {activeTab === 'enterprise' && (
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">所属企业 *</label>
                    <input
                      type="text"
                      defaultValue={editingPerson?.companyName || ''}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                      placeholder="请输入企业名称"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">参保类型 *</label>
                    <select
                      defaultValue={editingPerson?.type || (activeTab === 'personal' ? 'urban_resident' : 'urban_employee')}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                    >
                      {activeTab === 'personal' ? (
                        <>
                          <option value="urban_resident">城乡居民</option>
                          <option value="flexible">灵活就业</option>
                          <option value="rural">新农合</option>
                        </>
                      ) : (
                        <option value="urban_employee">城镇职工</option>
                      )}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">参保状态</label>
                    <select
                      defaultValue={editingPerson?.status || 'active'}
                      className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
                    >
                      <option value="active">正常</option>
                      <option value="suspended">暂停</option>
                      <option value="terminated">终止</option>
                    </select>
                  </div>
                </div>

                {activeTab === 'personal' && (
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700">缴费档次</label>
                    <div className="grid grid-cols-3 gap-3">
                      {paymentGrades.map((grade) => (
                        <label
                          key={grade.id}
                          className={`cursor-pointer rounded-lg border p-3 transition-all ${
                            editingPerson?.paymentGrade === grade.name
                              ? 'border-[#0891B2] bg-[#0891B2]/5'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name="paymentGrade"
                            value={grade.name}
                            defaultChecked={editingPerson?.paymentGrade === grade.name}
                            className="sr-only"
                          />
                          <div className="text-center">
                            <p className="font-medium text-gray-900">{grade.name}</p>
                            <p className="text-lg font-bold text-[#0891B2]">¥{grade.amount}</p>
                            <p className="text-xs text-gray-500">{grade.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  onClick={() => setShowModal(false)}
                  className="rounded-lg px-4 py-2 text-gray-600 transition hover:bg-gray-100"
                >
                  取消
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                >
                  保存
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 详情弹窗 */}
      <AnimatePresence>
        {showDetail && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#0891B2] to-[#22D3EE] flex items-center justify-center text-white text-2xl font-bold">
                    {showDetail.name[0]}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-[#134E4A]">{showDetail.name}</h3>
                    <p className="text-sm text-gray-500">{typeLabels[showDetail.type]}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetail(null)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="sr-only">关闭</span>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 flex items-center gap-2">
                    <User size={16} className="text-[#0891B2]" />
                    基本信息
                  </h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">身份证号</span>
                      <span className="font-mono">{showDetail.idCard}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">联系电话</span>
                      <span>{showDetail.phone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">参保日期</span>
                      <span>{showDetail.joinDate}</span>
                    </div>
                    {showDetail.companyName && (
                      <div className="flex justify-between">
                        <span className="text-gray-500">所属企业</span>
                        <span>{showDetail.companyName}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900 flex items-center gap-2">
                    <CreditCard size={16} className="text-[#0891B2]" />
                    账户信息
                  </h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">账户余额</span>
                      <span className="font-bold text-[#0891B2]">¥{showDetail.balance.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">缴费档次</span>
                      <span>{showDetail.paymentGrade || `¥${showDetail.annualFee}/年`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">最近缴费</span>
                      <span>{showDetail.lastPayment}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">缴费状态</span>
                      <span className={paymentStatusLabels[showDetail.paymentStatus].color}>
                        {paymentStatusLabels[showDetail.paymentStatus].label}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-100">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center gap-2">
                  <History size={16} className="text-[#0891B2]" />
                  最近操作记录
                </h4>
                <div className="space-y-2">
                  {[
                    { time: '2024-12-15 14:30', action: '缴纳2024年度医保费', amount: 600 },
                    { time: '2024-11-20 09:15', action: '门诊报销', amount: -280 },
                    { time: '2024-10-08 16:45', action: '账户划入', amount: 90 },
                  ].map((record, idx) => (
                    <div key={idx} className="flex items-center justify-between py-2 text-sm">
                      <span className="text-gray-500">{record.time}</span>
                      <span className="text-gray-700">{record.action}</span>
                      <span className={record.amount > 0 ? 'text-green-600' : 'text-gray-900'}>
                        {record.amount > 0 ? '+' : ''}¥{Math.abs(record.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  onClick={() => setShowDetail(null)}
                  className="rounded-lg px-4 py-2 text-gray-600 transition hover:bg-gray-100"
                >
                  关闭
                </button>
                <button
                  onClick={() => {
                    setShowDetail(null);
                    handleEdit(showDetail);
                  }}
                  className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                >
                  编辑信息
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
