import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, CreditCard, Calendar, CheckCircle, AlertCircle, 
  TrendingUp, Download, Filter, ChevronDown, Plus,
  Clock, DollarSign, FileText, Printer, RotateCcw
} from 'lucide-react';

// 缴费记录类型
interface PaymentRecord {
  id: string;
  insuredId: string;
  name: string;
  idCard: string;
  type: 'urban_employee' | 'urban_resident' | 'flexible' | 'rural';
  year: string;
  amount: number;
  paymentDate: string;
  dueDate: string;
  status: 'paid' | 'unpaid' | 'overdue';
  paymentMethod: 'online' | 'bank' | 'cash' | 'wechat' | 'alipay';
  invoiceNo: string;
  period: string;
}

// 缴费档次
interface PaymentGrade {
  id: string;
  name: string;
  amount: number;
  description: string;
  subsidy: number;
}

const paymentGrades: PaymentGrade[] = [
  { id: 'grade1', name: '一档（基础）', amount: 400, description: '基础医疗保障', subsidy: 700 },
  { id: 'grade2', name: '二档（标准）', amount: 600, description: '标准医疗保障', subsidy: 700 },
  { id: 'grade3', name: '三档（优质）', amount: 900, description: '优质医疗保障', subsidy: 700 },
];

const typeLabels: Record<string, string> = {
  urban_employee: '城镇职工',
  urban_resident: '城乡居民',
  flexible: '灵活就业',
  rural: '新农合',
};

const statusLabels: Record<string, { label: string; color: string; icon: any }> = {
  paid: { label: '已缴费', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  unpaid: { label: '待缴费', color: 'bg-yellow-100 text-yellow-700', icon: Clock },
  overdue: { label: '已逾期', color: 'bg-red-100 text-red-700', icon: AlertCircle },
};

const methodLabels: Record<string, string> = {
  online: '网上银行',
  bank: '银行柜台',
  cash: '现金',
  wechat: '微信支付',
  alipay: '支付宝',
};

// 模拟数据
const mockData: PaymentRecord[] = [
  { 
    id: 'PAY2024001', 
    insuredId: '1',
    name: '张三', 
    idCard: '110101199001011234',
    type: 'urban_resident',
    year: '2024',
    amount: 600,
    paymentDate: '2024-01-15',
    dueDate: '2024-03-31',
    status: 'paid',
    paymentMethod: 'alipay',
    invoiceNo: 'INV20240115001',
    period: '2024年度'
  },
  { 
    id: 'PAY2024002', 
    insuredId: '2',
    name: '李四', 
    idCard: '110101198505056789',
    type: 'flexible',
    year: '2024',
    amount: 400,
    paymentDate: '2024-02-20',
    dueDate: '2024-03-31',
    status: 'paid',
    paymentMethod: 'wechat',
    invoiceNo: 'INV20240220002',
    period: '2024年度'
  },
  { 
    id: 'PAY2024003', 
    insuredId: '3',
    name: '王五', 
    idCard: '110101199212123456',
    type: 'rural',
    year: '2024',
    amount: 400,
    paymentDate: '',
    dueDate: '2024-03-31',
    status: 'overdue',
    paymentMethod: 'cash',
    invoiceNo: '',
    period: '2024年度'
  },
  { 
    id: 'PAY2024004', 
    insuredId: '4',
    name: '赵六', 
    idCard: '110101199508081111',
    type: 'urban_employee',
    year: '2024',
    amount: 3600,
    paymentDate: '2024-01-10',
    dueDate: '2024-01-31',
    status: 'paid',
    paymentMethod: 'bank',
    invoiceNo: 'INV20240110004',
    period: '2024年度'
  },
];

export default function PaymentManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterYear, setFilterYear] = useState<string>('2024');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showGradeModal, setShowGradeModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PaymentRecord | null>(null);

  // 筛选数据
  const filteredData = mockData.filter(item => {
    const matchSearch = item.name.includes(searchTerm) || item.idCard.includes(searchTerm);
    const matchStatus = filterStatus === 'all' || item.status === filterStatus;
    const matchYear = filterYear === 'all' || item.year === filterYear;
    return matchSearch && matchStatus && matchYear;
  });

  // 统计数据
  const stats = {
    total: mockData.length,
    paid: mockData.filter(i => i.status === 'paid').length,
    unpaid: mockData.filter(i => i.status === 'unpaid').length,
    overdue: mockData.filter(i => i.status === 'overdue').length,
    totalAmount: mockData.reduce((sum, i) => sum + i.amount, 0),
    collectedAmount: mockData.filter(i => i.status === 'paid').reduce((sum, i) => sum + i.amount, 0),
    pendingAmount: mockData.filter(i => i.status !== 'paid').reduce((sum, i) => sum + i.amount, 0),
  };

  const handlePayment = (record: PaymentRecord) => {
    setSelectedRecord(record);
    setShowPaymentModal(true);
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-[#134E4A]">缴费管理</h2>
          <p className="text-sm text-gray-500 mt-1">管理医保费用缴纳与欠费催缴</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowGradeModal(true)}
            className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <DollarSign size={16} />
            缴费档次
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Download size={16} />
            导出
          </button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">应缴总额</p>
          <p className="text-2xl font-bold text-[#0891B2]">¥{stats.totalAmount.toLocaleString()}</p>
          <p className="text-xs text-gray-400 mt-1">{filterYear}年度</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">已收金额</p>
          <p className="text-2xl font-bold text-green-600">¥{stats.collectedAmount.toLocaleString()}</p>
          <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
            <TrendingUp size={12} />
            收缴率 {Math.round(stats.collectedAmount/stats.totalAmount*100)}%
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">待缴金额</p>
          <p className="text-2xl font-bold text-yellow-600">¥{stats.pendingAmount.toLocaleString()}</p>
          <p className="text-xs text-gray-400 mt-1">{stats.unpaid + stats.overdue} 人未缴</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
        >
          <p className="text-sm text-gray-500">逾期欠费</p>
          <p className="text-2xl font-bold text-red-600">{stats.overdue}</p>
          <p className="text-xs text-red-500 mt-1">需要催缴</p>
        </motion.div>
      </div>

      {/* 缴费档次展示 */}
      <div className="grid grid-cols-3 gap-4">
        {paymentGrades.map((grade, index) => (
          <motion.div
            key={grade.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
            className="bg-gradient-to-br from-[#0891B2]/5 to-[#22D3EE]/5 rounded-xl p-4 border border-[#0891B2]/20"
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-[#134E4A]">{grade.name}</h4>
              <span className="text-2xl font-bold text-[#0891B2]">¥{grade.amount}</span>
            </div>
            <p className="text-sm text-gray-600 mb-2">{grade.description}</p>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded">财政补贴 ¥{grade.subsidy}</span>
              <span>实际筹资 ¥{grade.amount + grade.subsidy}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* 搜索和筛选 */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="搜索姓名或身份证号"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-gray-200 py-2 pl-10 pr-4 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20"
          />
        </div>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={filterYear}
            onChange={(e) => setFilterYear(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white min-w-[120px]"
          >
            <option value="2024">2024年度</option>
            <option value="2023">2023年度</option>
            <option value="2022">2022年度</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="rounded-lg border border-gray-200 py-2 pl-9 pr-8 focus:border-[#0891B2] focus:outline-none appearance-none bg-white min-w-[120px]"
          >
            <option value="all">全部状态</option>
            <option value="paid">已缴费</option>
            <option value="unpaid">待缴费</option>
            <option value="overdue">已逾期</option>
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
        </div>
      </div>

      {/* 数据表格 */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="border-b border-gray-200 bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费单号</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保人</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">参保类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费年度</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">应缴金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">缴费期限</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((record, index) => {
              const StatusIcon = statusLabels[record.status].icon;
              return (
                <motion.tr
                  key={record.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <span className="text-sm font-mono text-gray-600">{record.id}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{record.name}</p>
                      <p className="text-xs text-gray-500">{record.idCard}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{typeLabels[record.type]}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{record.period}</td>
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">¥{record.amount}</td>
                  <td className="px-4 py-3">
                    <div className="text-sm">
                      <p className="text-gray-600">截止: {record.dueDate}</p>
                      {record.paymentDate && (
                        <p className="text-green-600 text-xs">实缴: {record.paymentDate}</p>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${statusLabels[record.status].color}`}>
                      <StatusIcon size={12} />
                      {statusLabels[record.status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {record.status !== 'paid' ? (
                      <button 
                        onClick={() => handlePayment(record)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#0891B2] text-white text-sm hover:bg-[#0891B2]/90 transition-colors"
                      >
                        <CreditCard size={14} />
                        缴费
                      </button>
                    ) : (
                      <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 text-sm hover:bg-gray-50 transition-colors">
                        <FileText size={14} />
                        发票
                      </button>
                    )}
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
        {filteredData.length === 0 && (
          <div className="py-12 text-center text-gray-400">
            <CreditCard size={48} className="mx-auto mb-3 opacity-30" />
            <p>暂无缴费记录</p>
          </div>
        )}
      </div>

      {/* 缴费弹窗 */}
      <AnimatePresence>
        {showPaymentModal && selectedRecord && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl"
            >
              <h3 className="text-lg font-semibold text-[#134E4A] mb-4">缴纳医保费用</h3>
              
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">参保人</span>
                  <span className="font-medium">{selectedRecord.name}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-500">缴费年度</span>
                  <span>{selectedRecord.period}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">应缴金额</span>
                  <span className="text-xl font-bold text-[#0891B2]">¥{selectedRecord.amount}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">支付方式</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'alipay', label: '支付宝', icon: '💙' },
                      { id: 'wechat', label: '微信支付', icon: '💚' },
                      { id: 'bank', label: '银行卡', icon: '💳' },
                    ].map((method) => (
                      <label key={method.id} className="cursor-pointer">
                        <input type="radio" name="paymentMethod" value={method.id} className="sr-only" defaultChecked={method.id === 'alipay'} />
                        <div className="border-2 border-gray-200 rounded-lg p-3 text-center hover:border-[#0891B2] transition-colors has-[:checked]:border-[#0891B2] has-[:checked]:bg-[#0891B2]/5">
                          <span className="text-2xl">{method.icon}</span>
                          <p className="text-xs mt-1">{method.label}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">备注</label>
                  <textarea
                    rows={2}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:border-[#0891B2] focus:outline-none focus:ring-2 focus:ring-[#0891B2]/20 resize-none"
                    placeholder="选填..."
                  />
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="rounded-lg px-4 py-2 text-gray-600 transition hover:bg-gray-100"
                >
                  取消
                </button>
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                >
                  确认支付 ¥{selectedRecord.amount}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 缴费档次详情弹窗 */}
      <AnimatePresence>
        {showGradeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-2xl rounded-xl bg-white p-6 shadow-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-[#134E4A]">缴费档次设置</h3>
                <button
                  onClick={() => setShowGradeModal(false)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <span className="sr-only">关闭</span>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="space-y-4">
                {paymentGrades.map((grade) => (
                  <div key={grade.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-gray-900">{grade.name}</h4>
                      <span className="text-2xl font-bold text-[#0891B2]">¥{grade.amount}</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{grade.description}</p>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <span className="text-gray-500">个人缴费</span>
                        <p className="font-medium">¥{grade.amount}</p>
                      </div>
                      <div className="bg-green-50 rounded-lg p-3">
                        <span className="text-green-600">财政补贴</span>
                        <p className="font-medium text-green-700">¥{grade.subsidy}</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center">
                      <span className="text-sm text-gray-500">实际筹资总额</span>
                      <span className="font-bold">¥{grade.amount + grade.subsidy}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setShowGradeModal(false)}
                  className="rounded-lg bg-[#0891B2] px-4 py-2 text-white transition hover:bg-[#0891B2]/90"
                >
                  关闭
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
