import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Building2, FileText, Search, Upload, CheckCircle, Clock,
  AlertCircle, Download, Eye, TrendingUp, DollarSign, Users,
  Calendar, ChevronRight, Filter, Plus, X
} from 'lucide-react';

const tabs = [
  { id: 'settlement', label: '费用结算', icon: DollarSign },
  { id: 'directory', label: '目录查询', icon: Search },
  { id: 'history', label: '结算单管理', icon: FileText },
  { id: 'profile', label: '机构信息', icon: Building2 }
];

const mockSettlementData = [
  { id: 'S001', patient: '张三', idCard: '1101****1234', amount: 5680, type: '住院', status: '待审核', date: '2024-01-15' },
  { id: 'S002', patient: '李四', idCard: '1101****5678', amount: 1280, type: '门诊', status: '已通过', date: '2024-01-14' }
];

const mockDirectoryData = [
  { code: 'A001', name: '阿莫西林', type: '药品', price: 25.5, status: '在目录' },
  { code: 'B001', name: '血常规检查', type: '诊疗', price: 80, status: '在目录' }
];

export default function InstitutionPortal() {
  const [activeTab, setActiveTab] = useState('settlement');
  const [showModal, setShowModal] = useState(false);

  const renderSettlement = () => (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索患者姓名" className="w-full pl-10 pr-4 py-2 border rounded-lg" />
        </div>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-lg">
          <Plus className="w-4 h-4" />新增结算
        </button>
      </div>
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium">结算单号</th>
              <th className="px-4 py-3 text-left text-sm font-medium">患者</th>
              <th className="px-4 py-3 text-left text-sm font-medium">金额</th>
              <th className="px-4 py-3 text-left text-sm font-medium">状态</th>
              <th className="px-4 py-3 text-left text-sm font-medium">操作</th>
            </tr>
          </thead>
          <tbody>
            {mockSettlementData.map((item) => (
              <tr key={item.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-mono">{item.id}</td>
                <td className="px-4 py-3 text-sm">{item.patient}</td>
                <td className="px-4 py-3 text-sm font-medium text-cyan-600">¥{item.amount}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 text-xs rounded ${item.status === '已通过' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{item.status}</span>
                </td>
                <td className="px-4 py-3"><button className="text-cyan-600 text-sm">查看</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderDirectory = () => (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="搜索药品/诊疗项目" className="w-full pl-10 pr-4 py-2 border rounded-lg" />
        </div>
        <select className="px-4 py-2 border rounded-lg">
          <option>全部类型</option>
          <option>药品</option>
          <option>诊疗</option>
          <option>耗材</option>
        </select>
      </div>
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium">编码</th>
              <th className="px-4 py-3 text-left text-sm font-medium">名称</th>
              <th className="px-4 py-3 text-left text-sm font-medium">类型</th>
              <th className="px-4 py-3 text-left text-sm font-medium">价格</th>
              <th className="px-4 py-3 text-left text-sm font-medium">状态</th>
            </tr>
          </thead>
          <tbody>
            {mockDirectoryData.map((item) => (
              <tr key={item.code} className="border-t hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-mono">{item.code}</td>
                <td className="px-4 py-3 text-sm font-medium">{item.name}</td>
                <td className="px-4 py-3 text-sm">{item.type}</td>
                <td className="px-4 py-3 text-sm">¥{item.price}</td>
                <td className="px-4 py-3"><span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">{item.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="bg-white rounded-xl border p-6">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 bg-cyan-100 rounded-xl flex items-center justify-center">
          <Building2 className="w-8 h-8 text-cyan-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold">北京协和医院</h3>
          <p className="text-sm text-gray-500">三级甲等医院</p>
        </div>
        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">协议正常</span>
      </div>
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">机构编码:</span> <span className="font-medium">110101001</span></div>
        <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">信用等级:</span> <span className="font-medium text-green-600">AAA</span></div>
        <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">协议有效期:</span> <span className="font-medium">2024-01-01 至 2024-12-31</span></div>
        <div className="p-3 bg-gray-50 rounded-lg"><span className="text-gray-500">联系电话:</span> <span className="font-medium">010-12345678</span></div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">医疗机构门户</h2>
          <p className="text-sm text-gray-500 mt-1">费用结算申请、目录查询、结算单管理</p>
        </div>
        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">医疗机构管理员</span>
      </div>

      <div className="flex gap-2 border-b">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center gap-2 px-4 py-3 text-sm font-medium ${activeTab === tab.id ? 'text-cyan-600 border-b-2 border-cyan-600' : 'text-gray-600'}`}>
            <tab.icon className="w-4 h-4" />{tab.label}
          </button>
        ))}
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        {activeTab === 'settlement' && renderSettlement()}
        {activeTab === 'directory' && renderDirectory()}
        {activeTab === 'history' && renderSettlement()}
        {activeTab === 'profile' && renderProfile()}
      </motion.div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="w-full max-w-lg bg-white rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">新增结算申请</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div><label className="block text-sm font-medium mb-1">患者身份证号</label><input type="text" className="w-full border rounded-lg px-3 py-2" /></div>
              <div><label className="block text-sm font-medium mb-1">结算类型</label><select className="w-full border rounded-lg px-3 py-2"><option>住院</option><option>门诊</option></select></div>
              <div><label className="block text-sm font-medium mb-1">费用清单</label><div className="border-2 border-dashed rounded-lg p-4 text-center text-gray-500"><Upload className="w-6 h-6 mx-auto mb-2" />点击上传</div></div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-gray-600">取消</button>
              <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-cyan-600 text-white rounded-lg">提交申请</button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
