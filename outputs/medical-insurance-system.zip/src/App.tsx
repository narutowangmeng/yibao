import React, { useState } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import RoleBasedSidebar from './components/Layout/RoleBasedSidebar';
import { Header } from './components/Layout/Header';
import Dashboard from './pages/Dashboard';
import InsuredManagement from './pages/InsuredManagement';
import Reimbursement from './pages/Reimbursement';
import PaymentManagement from './pages/PaymentManagement';
import Institutions from './pages/Institutions';
import Supervision from './pages/Supervision';
import Settings from './pages/Settings';
import UserManagement from './pages/admin/UserManagement';
import RoleManagement from './pages/admin/RoleManagement';
import DepartmentManagement from './pages/admin/DepartmentManagement';
import AuditCenter from './pages/audit/AuditCenter';
import FundManagement from './pages/finance/FundManagement';
import StatisticalReports from './pages/report/StatisticalReports';
import TreatmentDepartment from './pages/departments/TreatmentDepartment';
import FundSupervision from './pages/departments/FundSupervision';
import MedicalService from './pages/departments/MedicalService';
import OperatorWorkbench from './pages/workbench/OperatorWorkbench';
import AuditorWorkbench from './pages/workbench/AuditorWorkbench';
import InstitutionPortal from './pages/institution/InstitutionPortal';
import EmployerPortal from './pages/portal/EmployerPortal';
import PersonalService from './pages/portal/PersonalService';
import type { UserRole } from './types/roles';

const AVAILABLE_ROLES: { code: UserRole; name: string }[] = [
  { code: 'system_admin', name: '系统管理员' },
  { code: 'bureau_leader', name: '医保局领导' },
  { code: 'treatment_director', name: '待遇保障司负责人' },
  { code: 'fund_supervisor', name: '基金监管司负责人' },
  { code: 'medical_service_director', name: '医药服务管理司负责人' },
  { code: 'operator', name: '经办人员' },
  { code: 'auditor', name: '审核人员' },
  { code: 'finance_staff', name: '财务人员' },
  { code: 'institution_admin', name: '医疗机构管理员' },
  { code: 'employer_admin', name: '参保单位管理员' },
  { code: 'insured_person', name: '参保人员' },
];

const userRole: UserRole = 'treatment_director';

const pageTitles: Record<string, string> = {
  '/dashboard': '数据概览',
  '/treatment': '待遇保障司',
  '/fund-supervision': '基金监管司',
  '/medical-service': '医药服务管理司',
  '/workbench/operator': '经办工作台',
  '/workbench/auditor': '审核工作台',
  '/institutions': '医疗机构门户',
  '/employer': '参保单位门户',
  '/personal': '个人服务大厅',
  '/users': '用户管理',
  '/roles': '角色权限',
  '/settings': '系统设置',
};

function AppContent() {
  const location = useLocation();
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // 从 URL 参数读取角色，如果没有则使用默认值
  const getRoleFromUrl = (): UserRole => {
    const params = new URLSearchParams(window.location.search);
    const roleParam = params.get('role') as UserRole;
    if (roleParam && AVAILABLE_ROLES.find(r => r.code === roleParam)) {
      return roleParam;
    }
    return userRole;
  };

  const [currentRole, setCurrentRole] = useState<UserRole>(getRoleFromUrl());
  const [showRoleSwitcher, setShowRoleSwitcher] = useState(false);
  const currentPath = location.pathname;
  const title = pageTitles[currentPath] || '数据概览';

  const getActiveTab = () => {
    const path = currentPath.replace('/', '');
    return path || 'dashboard';
  };

  const handleRoleChange = (role: UserRole) => {
    // 修改 URL 参数并跳转到对应角色的首页
    const url = new URL(window.location.href);
    url.searchParams.set('role', role);
    // 根据角色设置默认首页
    let defaultPath = '#/dashboard';
    if (role === 'institution_admin') defaultPath = '#/institutions';
    else if (role === 'employer_admin') defaultPath = '#/employer';
    else if (role === 'insured_person') defaultPath = '#/personal';
    else if (role === 'operator') defaultPath = '#/workbench/operator';
    else if (role === 'auditor') defaultPath = '#/workbench/auditor';
    window.location.href = url.toString().replace(/#.*$/, '') + defaultPath;
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-900' : 'bg-gray-50'}`}>
      <RoleBasedSidebar activeTab={getActiveTab()} userRole={currentRole} />
      <div className="ml-64">
        <Header title={title} theme={theme} />
        <div className="px-6 pt-4">
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 border border-cyan-200 rounded-lg p-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-600">当前角色:</span>
              <span className="px-3 py-1 bg-cyan-600 text-white text-sm rounded-full font-medium">
                {AVAILABLE_ROLES.find(r => r.code === currentRole)?.name}
              </span>
              <span className="text-xs text-gray-500">
                ({currentRole === 'treatment_director' || currentRole === 'fund_supervisor' || currentRole === 'medical_service_director' ? '管理层' :
                  currentRole === 'operator' || currentRole === 'auditor' || currentRole === 'finance_staff' ? '执行层' :
                  currentRole === 'system_admin' || currentRole === 'bureau_leader' ? '决策层' : '外部用户'})
              </span>
            </div>
            <button
              onClick={() => setShowRoleSwitcher(!showRoleSwitcher)}
              className="text-sm text-cyan-600 hover:text-cyan-700 font-medium flex items-center gap-1"
            >
              切换角色
            </button>
          </div>
          {showRoleSwitcher && (
            <div className="mt-2 bg-white border border-gray-200 rounded-lg shadow-lg p-4">
              <p className="text-sm text-gray-500 mb-3">选择角色进行体验:</p>
              <div className="grid grid-cols-4 gap-2">
                {AVAILABLE_ROLES.map((role) => (
                  <button
                    key={role.code}
                    onClick={() => handleRoleChange(role.code)}
                    className={`px-3 py-2 text-sm rounded-lg border transition-colors ${
                      currentRole === role.code
                        ? 'bg-cyan-600 text-white border-cyan-600'
                        : 'bg-white text-gray-700 border-gray-200 hover:border-cyan-400 hover:bg-cyan-50'
                    }`}
                  >
                    {role.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <main className="p-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />

            {/* 管理层 - 三个司 */}
            <Route path="/treatment" element={<TreatmentDepartment />} />
            <Route path="/fund-supervision" element={<FundSupervision />} />
            <Route path="/medical-service" element={<MedicalService />} />

            {/* 执行层 - 工作台 */}
            <Route path="/workbench/operator" element={<OperatorWorkbench />} />
            <Route path="/workbench/auditor" element={<AuditorWorkbench />} />

            {/* 外部用户门户 */}
            <Route path="/institutions" element={<InstitutionPortal />} />
            <Route path="/employer" element={<EmployerPortal />} />
            <Route path="/personal" element={<PersonalService />} />

            {/* 系统管理 */}
            <Route path="/users" element={<UserManagement />} />
            <Route path="/roles" element={<RoleManagement />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
}

export default App;
