import React, { useState } from 'react';
import { Search, Bell, User, ChevronDown, LogOut, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface HeaderProps {
  title: string;
  theme: 'light' | 'dark';
}

export const Header: React.FC<HeaderProps> = ({ title, theme }) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const isDark = theme === 'dark';
  const bgColor = isDark ? 'bg-slate-900' : 'bg-white';
  const textColor = isDark ? 'text-slate-100' : 'text-slate-800';
  const borderColor = isDark ? 'border-slate-700' : 'border-slate-200';
  const inputBg = isDark ? 'bg-slate-800' : 'bg-slate-50';

  return (
    <header className={`h-16 ${bgColor} ${borderColor} border-b flex items-center justify-between px-6 sticky top-0 z-50`}>
      <h1 className={`text-xl font-semibold ${textColor}`}>{title}</h1>

      <div className="flex items-center gap-4">
        <div className={`flex items-center gap-2 ${inputBg} rounded-lg px-3 py-2 w-64`}>
          <Search size={18} className={isDark ? 'text-slate-400' : 'text-slate-500'} />
          <input
            type="text"
            placeholder="搜索..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className={`bg-transparent outline-none text-sm w-full ${textColor} placeholder:${isDark ? 'text-slate-500' : 'text-slate-400'}`}
          />
        </div>

        <button className={`relative p-2 rounded-lg hover:${isDark ? 'bg-slate-800' : 'bg-slate-100'} transition-colors`}>
          <Bell size={20} className={isDark ? 'text-slate-300' : 'text-slate-600'} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
        </button>

        <div className="relative">
          <button
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
            className={`flex items-center gap-2 p-2 rounded-lg hover:${isDark ? 'bg-slate-800' : 'bg-slate-100'} transition-colors`}
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center">
              <User size={16} className="text-white" />
            </div>
            <span className={`text-sm font-medium ${textColor}`}>管理员</span>
            <ChevronDown size={16} className={isDark ? 'text-slate-400' : 'text-slate-500'} />
          </button>

          <AnimatePresence>
            {isUserMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`absolute right-0 top-full mt-2 w-48 ${isDark ? 'bg-slate-800' : 'bg-white'} rounded-lg shadow-lg border ${borderColor} py-2`}
              >
                <button className={`w-full flex items-center gap-3 px-4 py-2 text-sm ${textColor} hover:${isDark ? 'bg-slate-700' : 'bg-slate-50'} transition-colors`}>
                  <Settings size={16} />
                  系统设置
                </button>
                <button className={`w-full flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:${isDark ? 'bg-slate-700' : 'bg-slate-50'} transition-colors`}>
                  <LogOut size={16} />
                  退出登录
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
};
