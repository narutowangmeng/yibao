export type UserRole =
  | 'system_admin'
  | 'bureau_leader'
  | 'treatment_director'
  | 'fund_supervisor'
  | 'medical_service_director'
  | 'office_director'
  | 'operator'
  | 'auditor'
  | 'finance_staff'
  | 'institution_admin'
  | 'employer_admin'
  | 'insured_person';

export interface RoleConfig {
  code: UserRole;
  name: string;
  department: string;
  level: 1 | 2 | 3;
  description: string;
  permissions: Permission[];
}

export type Permission =
  | 'dashboard:view'
  | 'insured:view' | 'insured:create' | 'insured:edit' | 'insured:delete'
  | 'reimbursement:view' | 'reimbursement:create' | 'reimbursement:audit' | 'reimbursement:approve'
  | 'payment:view' | 'payment:create' | 'payment:audit'
  | 'institutions:view' | 'institutions:manage'
  | 'supervision:view' | 'supervision:risk' | 'supervision:audit' | 'supervision:inspect'
  | 'finance:view' | 'finance:allocate' | 'finance:settle'
  | 'reports:view' | 'reports:export'
  | 'users:view' | 'users:manage'
  | 'roles:view' | 'roles:manage'
  | 'settings:view' | 'settings:system'
  | 'treatment:policy' | 'treatment:directory' | 'treatment:benefit'
  | 'medical:institution' | 'medical:drug' | 'medical:price' | 'medical:service'
  | 'office:document' | 'office:meeting' | 'office:archive';

export const ROLE_CONFIGS: Record<UserRole, RoleConfig> = {
  system_admin: {
    code: 'system_admin',
    name: '系统管理员',
    department: '信息中心',
    level: 1,
    description: '负责系统配置、用户管理、权限分配、数据安全',
    permissions: [
      'dashboard:view', 'users:view', 'users:manage', 'roles:view', 'roles:manage',
      'settings:view', 'settings:system', 'reports:view', 'reports:export'
    ]
  },
  bureau_leader: {
    code: 'bureau_leader',
    name: '医保局领导',
    department: '局领导',
    level: 1,
    description: '统筹全局工作，审批重大决策，查看全局数据',
    permissions: [
      'dashboard:view', 'insured:view', 'reimbursement:view', 'payment:view',
      'institutions:view', 'supervision:view', 'finance:view', 'reports:view', 'reports:export',
      'treatment:policy', 'medical:institution', 'medical:drug', 'medical:price'
    ]
  },
  treatment_director: {
    code: 'treatment_director',
    name: '待遇保障司负责人',
    department: '待遇保障司',
    level: 2,
    description: '负责参保管理、待遇政策制定、医保目录管理、筹资政策、长期护理保险',
    permissions: [
      'dashboard:view', 'insured:view', 'insured:create', 'insured:edit',
      'reimbursement:view', 'reimbursement:audit', 'payment:view',
      'treatment:policy', 'treatment:directory', 'treatment:benefit', 'reports:view'
    ]
  },
  fund_supervisor: {
    code: 'fund_supervisor',
    name: '基金监管司负责人',
    department: '基金监管司',
    level: 2,
    description: '负责基金监管、飞行检查、违规查处、风险监控、智能监管',
    permissions: [
      'dashboard:view', 'supervision:view', 'supervision:risk', 'supervision:audit',
      'supervision:inspect', 'institutions:view', 'finance:view', 'reports:view', 'reports:export'
    ]
  },
  medical_service_director: {
    code: 'medical_service_director',
    name: '医药服务管理司负责人',
    department: '医药服务管理司',
    level: 2,
    description: '负责医疗机构管理、药品目录、价格管理、招标采购、医疗服务项目管理',
    permissions: [
      'dashboard:view', 'institutions:view', 'institutions:manage',
      'medical:institution', 'medical:drug', 'medical:price', 'medical:service', 'reports:view'
    ]
  },
  office_director: {
    code: 'office_director',
    name: '办公室负责人',
    department: '办公室',
    level: 2,
    description: '负责公文管理、会议组织、档案管理、综合协调、信息公开',
    permissions: [
      'dashboard:view', 'reports:view', 'office:document', 'office:meeting', 'office:archive', 'settings:view'
    ]
  },
  operator: {
    code: 'operator',
    name: '经办人员',
    department: '各级经办机构',
    level: 3,
    description: '负责日常业务办理、参保登记、费用报销受理',
    permissions: [
      'dashboard:view', 'insured:view', 'insured:create', 'insured:edit',
      'reimbursement:view', 'reimbursement:create', 'payment:view', 'payment:create'
    ]
  },
  auditor: {
    code: 'auditor',
    name: '审核人员',
    department: '审核科',
    level: 3,
    description: '负责业务审核、稽核检查、费用核查',
    permissions: [
      'dashboard:view', 'insured:view', 'reimbursement:view', 'reimbursement:audit',
      'payment:view', 'payment:audit', 'supervision:view', 'supervision:audit', 'reports:view'
    ]
  },
  finance_staff: {
    code: 'finance_staff',
    name: '财务人员',
    department: '财务科',
    level: 3,
    description: '负责基金管理、结算拨付、财务报表',
    permissions: [
      'dashboard:view', 'finance:view', 'finance:allocate', 'finance:settle',
      'payment:view', 'reimbursement:view', 'reports:view', 'reports:export'
    ]
  },
  institution_admin: {
    code: 'institution_admin',
    name: '医疗机构管理员',
    department: '定点医疗机构',
    level: 3,
    description: '负责机构业务管理、医保结算申请',
    permissions: [
      'dashboard:view', 'institutions:view', 'reimbursement:view', 'reimbursement:create', 'reports:view'
    ]
  },
  employer_admin: {
    code: 'employer_admin',
    name: '参保单位管理员',
    department: '参保单位',
    level: 3,
    description: '负责单位参保管理、员工缴费',
    permissions: [
      'dashboard:view', 'insured:view', 'insured:create', 'payment:view', 'payment:create'
    ]
  },
  insured_person: {
    code: 'insured_person',
    name: '参保人员',
    department: '个人',
    level: 3,
    description: '个人业务查询办理',
    permissions: ['dashboard:view', 'insured:view', 'reimbursement:view', 'payment:view']
  }
};

export const DEPARTMENT_MODULES: Record<string, { name: string; modules: string[] }> = {
  treatment_director: {
    name: '待遇保障司',
    modules: [
      '参保管理 - 参保登记、信息变更、关系转移接续',
      '缴费管理 - 筹资政策、缴费核定、催缴管理',
      '待遇政策 - 医保待遇标准制定、待遇调整',
      '医保目录 - 药品目录、诊疗项目目录、医用耗材目录管理',
      '长期护理保险 - 失能评估、护理服务管理',
      '异地就医 - 异地备案、结算管理'
    ]
  },
  fund_supervisor: {
    name: '基金监管司',
    modules: [
      '基金监管 - 基金收支监控、风险预警',
      '飞行检查 - 现场检查、专项检查',
      '智能监管 - 大数据监控、规则库管理',
      '违规查处 - 欺诈骗保查处、违规处理',
      '信用管理 - 定点机构信用评价、黑名单管理',
      '举报投诉 - 举报受理、奖励发放'
    ]
  },
  medical_service_director: {
    name: '医药服务管理司',
    modules: [
      '医疗机构管理 - 定点机构准入、协议管理、退出管理',
      '药品管理 - 药品目录调整、集采管理、价格监测',
      '医疗服务价格 - 价格项目制定、价格调整',
      '招标采购 - 药品耗材招标、采购监管',
      '支付方式改革 - DRG/DIP付费、按病种付费',
      '医疗服务行为监管 - 诊疗规范、合理用药'
    ]
  },
  office_director: {
    name: '办公室',
    modules: [
      '公文管理 - 发文、收文、传阅',
      '会议管理 - 会议组织、纪要管理',
      '档案管理 - 文书档案、业务档案',
      '信息公开 - 政务公开、政策解读',
      '信访接待 - 群众来访、来信处理',
      '综合协调 - 部门协调、督办落实'
    ]
  }
};

export const hasPermission = (role: UserRole, permission: Permission): boolean => {
  return ROLE_CONFIGS[role].permissions.includes(permission);
};

export const getRoleName = (role: UserRole): string => ROLE_CONFIGS[role].name;

export const getRoleLevel = (role: UserRole): number => ROLE_CONFIGS[role].level;

export const getDepartmentName = (role: UserRole): string => ROLE_CONFIGS[role].department;
